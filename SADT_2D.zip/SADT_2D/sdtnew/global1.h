#ifndef GLOBAL_H
#define GLOBAL_H

#endif // GLOBAL_H
unsigned short **colorEDT,**colorEDTR,**slope1,**direction2,*componentcount,**NDR1,**NDR2,**sdtr2,**sdtr3,**ndr2,
**binary,**EDT,**nedtr,**nedt,**a,**a1,**dotproduct,**b,**boundary,**skel1,**colornrdr,**scaleMap1,**scaleMap2,**sdtr1,**colorsdtr,
**prewitGrad,**iprewitGrad,**colorprewittgrad,**colorprewittgrad1,**icolorprewittgrad,**icolorprewittgrad1,**colordirection,**NDR,**visited;
double **gradxp,**gradyp,**realprewit,**realprewit1,**direction,**direction1,**slope,**avgGradxp,**avgGradyp,**rdr;
double **DR,**DRN,**DR1,**avgDR,**realNDR,**realNDR1,**realdotproduct,**scaleMap,**sdtr,**sdtr4,maxglobalDT;
int c,r,r1,c1,nrflag=0,**skel,pf,CIth,gxi,gyj,pathflag=0,sth,coreth,sx1,sx2,sy1,sy2,sx3,sy3;
unsigned int **intfocal;

double gdtmax=-10000.0,gdtmin=10000.0;
struct point
{
    int x,y;
    unsigned short colorgrad;
    double direction,dotp;
};
point path[1000];
int p1,q1,p2,q2,bpcount=0,cc=0,cc1=0;
unsigned short maxi=0,mini=65500;
double up,uq;

struct NB
{
    double x,y,theta;
};
struct NB NN[2000][2000];

struct NB1
{
  int x,y;
};
struct NB1 NN1[1000][1000];
//struct realpoint
//{
//    double x,y;
//};

//struct realpoint rp[5000];
void saveProfile(unsigned short **,char *);
void saveProfile(double **,char *);
void dfs(int,int);
void calculate_RCI(double **,double **,unsigned short **,double,double);
void calculate_FCI(unsigned short **,unsigned short **,unsigned short **,int,int);
void calculate_CI(unsigned short **,unsigned short **,unsigned short **,int,int);
void calculate_EDT();
void calculate_FDT(unsigned short **,unsigned short **,unsigned short**,int);
void calculate_CDT(unsigned short **,unsigned short **,unsigned short**,int);
void calculate_flux(unsigned short **);
void calculate_flux(double **);
void compute_gradx(double **);
void compute_grady(double **);
void compute_grad();
void compute_gradx5(double **);
void compute_grady5(double **);
void compute_grad5();
void oldGradstraightline(int,int);
void geodesic(int,int);
void geodesic1(int,int);
void geodesic2(int,int);
void reVgeodesic(int,int);

