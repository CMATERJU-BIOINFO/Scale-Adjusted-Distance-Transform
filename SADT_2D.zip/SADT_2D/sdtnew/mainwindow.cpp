#include "mainwindow.h"
#include "ui_mainwindow.h"
#include "global1.h"
#include<QFileDialog>
#include<QDebug>
#include <iomanip>
#include <string>
#include <map>
#include <random>
#include <cmath>
#include<QtGui>
#include<QPainter>
#include<QEasingCurve>
#include<time.h>
#include<float.h>
#include<iostream>
#include <QQueue>
#define lo 1
#define d1 3
#define d2 4
#define mf 1
#define rd1 1.000000
#define rd2 1.414213

struct pp
{
    int x,y;
};
pp pnt;
void add_gaussian();
void linedrawing(int,int,int,int);
short gx[9]={
    -1,0,1,
    -1,0,1,
    -1,0,1
};
short gy[9]={

     1,1,1,
     0,0,0,
     -1,-1,-1
};

short gx5[125]={

    -1,-2,0,2,1,
    -4,-8,0,8,4,
    -6,-12,0,12,6,
    -4,-8,0,8,4,
    -1,-2,0,2,1
};

short gy5[125]={

    1,4,6,4,1,
    2,8,12,8,2,
    0,0,0,0,0,
    -2,-8,-12,-8,-2,
    -1,-4,-6,-4,-1
};

short npp[9][2]={

    {-1,-1},{0,-1},{1,-1},
    {-1,0},{0,0},{1,0},
    {-1,1},{0,1},{1,1}
};
short npp4[5][2]={
           {0,-1},
    {-1,0},{0,0},{1,0},
           {0,1}
};

short angle[9]={
                         7,0,7,
                         10,0,10,
                         7,0,7
};
double realangle[9]={
    0.707106,  1.0, 0.707106,
       1.0,         0.0, 1.0,
    0.707106,   1.0, 0.707106
};
double neighbor[9]={1.4142136,1.0,1.4142136,1.0,0.0,1.0,1.4142136,1.0,1.4142136};
unsigned short neighbor1[9]={d2,d1,d2,d1,0,d1,d2,d1,d2};
unsigned short temp[3][3],curlabel=1,compsize[10];
int steps,pcount=0,xcentre,ycentre;
unsigned int pixcount=0;
double rmaj,rminor,rx,ry,rootvalue[6],rootvalue1[5],temp1[3][3],realcurlabel=1.0,realcompsize[10];
int xleft=10000, xright=-1,yup=-1,ydown=10000,xlx,xly,yux,yuy,xl1,yd1,xl2,yd2,xr1,yd3,xr2,yd4;
int histCI[255],histFocal[255],e8Neighbors[8];
int temparr[3][3],curlabel1=0,maxii=0,minii=INT_MAX;

QImage image;
QQueue<point> pointq;
MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::on_loadimg_clicked()
{

    int i,j,red,green,blue,intensity;
    QString filepath;
    QRgb value;
    filepath=QFileDialog::getOpenFileName(this,tr("Choose"),"../../../",tr("Images(*.png *.bmp *.jpg *.jpeg *.tif *.tiff *.lsm)"));
    if(QString::compare(filepath,QString())!=0)
    {
        QRgb value;
        bool valid;
        valid=image.load(filepath);
        //qDebug()<<"value of valid"<<valid;
        c=image.width();
        r=image.height();
        c1=c;
        r1=r;
        a=(unsigned short **)calloc(sizeof(unsigned short *),c);
        for(int i=0;i<c;i++)
        {
            a[i]=(unsigned short *)calloc(sizeof(unsigned short),r);
        }

        //qDebug()<<r<<c;
        if(valid)
        {
            ui->lblimage_1->setMinimumHeight(r1);
            ui->lblimage_1->setMinimumWidth(c1);
           // ui->lblimage_1->setPixmap(QPixmap::fromImage(image).scaled(ui->lblimage_1->width(),ui->lblimage_1->height(),Qt::KeepAspectRatio));
            ui->lblimage_1->setPixmap(QPixmap::fromImage(image));
            ui->lblimage_1->adjustSize();
        }
        else
        {
           //qDebug()<<"Invalid";
        }
        image=image.convertToFormat(QImage::Format_RGB888);
        for(int j=0;j<r;j++)
                {
                    for(int i=0;i<c;i++)
                    {

                        value=image.pixel(i,j);
                        red=qRed(value);
                        green=qGreen(value);
                        blue=qBlue(value);
                        intensity=red;
                        if(blue>intensity)intensity=blue;
                        if(green>intensity)intensity=green;
                        if(intensity>0)
                        {
                            a[i][j]=255;
                            //qDebug()<<"Intensity 255 available";
                        }
                        else
                        {
                            a[i][j]=0;
                           // qDebug()<<"Intensity <0 available";
                        }
                    }
                }
    }

    for(int j=0;j<r;j++)
            {
                for(int i=0;i<c;i++)
                {

                    value=image.pixel(i,j);
                    red=qRed(value);
                    green=qGreen(value);
                    blue=qBlue(value);
                    image.setPixel(i,j,qRgb(red,green,blue));
                    //if(!red&&!green&&!blue)image.setPixel(i,j,qRgb(255,255,255));
                }
            }
    ui->lblimage_1->setMinimumHeight(r1);
    ui->lblimage_1->setMinimumWidth(c1);
   // ui->lblimage_1->setPixmap(QPixmap::fromImage(image).scaled(ui->lblimage_1->width(),ui->lblimage_1->height(),Qt::KeepAspectRatio));
    ui->lblimage_1->setPixmap(QPixmap::fromImage(image));
    ui->lblimage_1->adjustSize();
    free_memory1();
    allocate_memory1();
    draw_image1(a,ui->lblimage_1);
    /*FILE *fp;
    fp=fopen("intensity.csv","wb");
    for(int j=0;j<r;j++)
    {
        for(int i=0;i<c;i++)
        {
            fprintf(fp,"%d,",a[i][j]);
        }
        fprintf(fp,"%c",'\n');
    }
    fclose(fp);*/
}

void MainWindow::allocate_memory1()
{
        binary=(unsigned short **)calloc(sizeof(unsigned short *),c1);
        dotproduct=(unsigned short **)calloc(sizeof(unsigned short *),c1);
        scaleMap=(double **)calloc(sizeof(double *),c1);
        scaleMap1=(unsigned short **)calloc(sizeof(unsigned short *),c1);
        scaleMap2=(unsigned short **)calloc(sizeof(unsigned short *),c1);
        boundary=(unsigned short **)calloc(sizeof(unsigned short *),c1);
        nedt=(unsigned short **)calloc(sizeof(unsigned short *),c1);
        nedtr=(unsigned short **)calloc(sizeof(unsigned short *),c1);
        EDT=(unsigned short **)calloc(sizeof(unsigned short *),c1);
        direction=(double **)calloc(sizeof(double *),c1);
        realNDR=(double **)calloc(sizeof(double *),c1);
        realNDR1=(double **)calloc(sizeof(double *),c1);
        colornrdr=(unsigned short **)calloc(sizeof(unsigned short *),c1);
        colorEDT=(unsigned short **)calloc(sizeof(unsigned short *),c1);
        colorEDTR=(unsigned short **)calloc(sizeof(unsigned short *),c1);
        DR=(double **)calloc(sizeof(double *),c1);
        sdtr=(double **)calloc(sizeof(double *),c1);
        sdtr4=(double **)calloc(sizeof(double *),c1);
        realdotproduct=(double **)calloc(sizeof(double *),c1);
        DRN=(double **)calloc(sizeof(double *),c1);
        NDR=(unsigned short **)calloc(sizeof(unsigned short *),c1);
        NDR1=(unsigned short **)calloc(sizeof(unsigned short *),c1);
        //ndr1=(unsigned short **)calloc(sizeof(unsigned short *),c1);
        ndr2=(unsigned short **)calloc(sizeof(unsigned short *),c1);
        DR1=(double **)calloc(sizeof(double *),c1);
        avgDR=(double **)calloc(sizeof(double *),c1);
        gradxp=(double **)calloc(sizeof(double *),c1);
        gradyp=(double **)calloc(sizeof(double *),c1);
        avgGradxp=(double **)calloc(sizeof(double *),c1);
        avgGradyp=(double **)calloc(sizeof(double *),c1);
        prewitGrad=(unsigned short **)calloc(sizeof(unsigned short *),c1);
        colorprewittgrad=(unsigned short **)calloc(sizeof(unsigned short *),c1);
        colorprewittgrad1=(unsigned short **)calloc(sizeof(unsigned short *),c1);
        realprewit=(double **)calloc(sizeof(double *),c1);
        realprewit1=(double **)calloc(sizeof(double *),c1);
        colordirection=(unsigned short **)calloc(sizeof(unsigned short *),c1);
        skel1=(unsigned short **)calloc(sizeof(unsigned short *),c1);
        direction1=(double **)calloc(sizeof(double *),c1);
        slope=(double **)calloc(sizeof(double *),c1);
        slope1=(unsigned short **)calloc(sizeof(unsigned short *),c1);
        visited=(unsigned short **)calloc(sizeof(unsigned short *),c1);
        direction2=(unsigned short **)calloc(sizeof(unsigned short *),c1);
        sdtr1=(unsigned short **)calloc(sizeof(unsigned short *),c1);
        sdtr2=(unsigned short **)calloc(sizeof(unsigned short *),c1);
        sdtr3=(unsigned short **)calloc(sizeof(unsigned short *),c1);
        colorsdtr=(unsigned short **)calloc(sizeof(unsigned short *),c1);
        for(int i=0;i<c1;i++)
        {
            boundary[i]=(unsigned short *)calloc(sizeof(unsigned short),r1);
            dotproduct[i]=(unsigned short *)calloc(sizeof(unsigned short),r1);
            scaleMap[i]=(double *)calloc(sizeof(double),r1);
            scaleMap1[i]=(unsigned short *)calloc(sizeof(unsigned short),r1);
            scaleMap2[i]=(unsigned short *)calloc(sizeof(unsigned short),r1);
            binary[i]=(unsigned short *)calloc(sizeof(unsigned short),r1);
            nedt[i]=(unsigned short *)calloc(sizeof(unsigned short),r1);
            nedtr[i]=(unsigned short *)calloc(sizeof(unsigned short),r1);
            skel1[i]=(unsigned short *)calloc(sizeof(unsigned short),r1);
            EDT[i]=(unsigned short *)calloc(sizeof(unsigned short),r1);
            direction[i]=(double *)calloc(sizeof(double),r1);
            realdotproduct[i]=(double *)calloc(sizeof(double),r1);
            colornrdr[i]=(unsigned short *)calloc(sizeof(unsigned short),r1);
            colorEDT[i]=(unsigned short *)calloc(sizeof(unsigned short),r1);
            colorEDTR[i]=(unsigned short *)calloc(sizeof(unsigned short),r1);
            DR[i]=(double *)calloc(sizeof(double),r1);
            sdtr[i]=(double *)calloc(sizeof(double),r1);
            sdtr4[i]=(double *)calloc(sizeof(double),r1);
            DRN[i]=(double *)calloc(sizeof(double),r1);
            NDR[i]=(unsigned short *)calloc(sizeof(unsigned short),r1);
            NDR1[i]=(unsigned short *)calloc(sizeof(unsigned short),r1);
            //ndr1[i]=(unsigned short *)calloc(sizeof(unsigned short),r1);
            ndr2[i]=(unsigned short *)calloc(sizeof(unsigned short),r1);
            realNDR[i]=(double *)calloc(sizeof(double),r1);
            realNDR1[i]=(double *)calloc(sizeof(double),r1);
            DR1[i]=(double *)calloc(sizeof(double),r1);
            avgDR[i]=(double *)calloc(sizeof(double),r1);
            gradxp[i]=(double *)calloc(sizeof(double),r1);
            gradyp[i]=(double *)calloc(sizeof(double),r1);
            avgGradxp[i]=(double *)calloc(sizeof(double),r1);
            avgGradyp[i]=(double *)calloc(sizeof(double),r1);
            prewitGrad[i]=(unsigned short *)calloc(sizeof(unsigned short),r1);
            colorprewittgrad[i]=(unsigned short *)calloc(sizeof(unsigned short),r1);
            colorprewittgrad1[i]=(unsigned short *)calloc(sizeof(unsigned short),r1);
            colordirection[i]=(unsigned short *)calloc(sizeof(unsigned short),r1);
            direction1[i]=(double *)calloc(sizeof(double),r1);
            realprewit[i]=(double *)calloc(sizeof(double),r1);
            realprewit1[i]=(double *)calloc(sizeof(double),r1);
            slope[i]=(double *)calloc(sizeof(double),r1);
            slope1[i]=(unsigned short *)calloc(sizeof(unsigned short),r1);
            visited[i]=(unsigned short *)calloc(sizeof(unsigned short),r1);
            direction2[i]=(unsigned short *)calloc(sizeof(unsigned short),r1);
            sdtr1[i]=(unsigned short *)calloc(sizeof(unsigned short),r1);
            sdtr2[i]=(unsigned short *)calloc(sizeof(unsigned short),r1);
            sdtr3[i]=(unsigned short *)calloc(sizeof(unsigned short),r1);
            colorsdtr[i]=(unsigned short *)calloc(sizeof(unsigned short),r1);
         }
}

void MainWindow::free_memory1()
{
     free(binary);binary=NULL;
     free(colornrdr);colornrdr=NULL;
     free(nedt);nedt=NULL;
     free(nedtr);nedtr=NULL;
     free(EDT);EDT=NULL;
     free(colorEDT);colorEDT=NULL;
     free(colorEDTR);colorEDT=NULL;
     free(DR);DR=NULL;
     free(DRN);DRN=NULL;
     free(NDR);NDR=NULL;
     free(realNDR);realNDR=NULL;
     free(avgDR);avgDR=NULL;
     free(DR1);DR1=NULL;
     free(boundary);boundary=NULL;
     free(dotproduct);dotproduct=NULL;
     free(realdotproduct);realdotproduct=NULL;
     free(gradxp);gradxp=NULL;
     free(gradyp);gradyp=NULL;
     free(avgGradxp);avgGradxp=NULL;
     free(avgGradyp);avgGradyp=NULL;
     free(prewitGrad);prewitGrad=NULL;
     free(colorprewittgrad);colorprewittgrad=NULL;
     free(colorprewittgrad1);colorprewittgrad1=NULL;
     free(scaleMap);scaleMap=NULL;
     free(scaleMap1);scaleMap1=NULL;
     free(scaleMap2);scaleMap2=NULL;
     free(direction);direction=NULL;
     free(direction1);direction1=NULL;
     free(colordirection);colordirection=NULL;
     free(slope);slope=NULL;
     free(slope1);slope1=NULL;
     free(NDR);NDR=NULL;
     //free(ndr1);ndr1=NULL;
     free(ndr2);ndr2=NULL;
     free(visited);visited=NULL;
     free(skel1);skel1=NULL;
     free(sdtr);sdtr=NULL;
     free(sdtr1);sdtr1=NULL;
     free(sdtr2);sdtr2=NULL;
     free(colorsdtr);colorsdtr=NULL;
     free(NDR1);NDR1=NULL;
     free(realNDR1);realNDR1=NULL;
     free(sdtr4);sdtr4=NULL;
     free(sdtr3);sdtr3=NULL;
     free(realprewit1);
}

void MainWindow::mouseMoveEvent(QMouseEvent *e)
{
 int x=e->pos().x();
 int y=e->pos().y();
 if(x>=0&&x<c&&y>=0&&y<r)
 {

 }
 else if(x>=r&&x<ui->lblimage_1->x());
 else if(x>=ui->lblimage_1->x()&&x<(ui->lblimage_1->x()+c1)&&y>=0)
 {
     //ui->curX_2->setNum(x-ui->lblimage_1->x());
     //ui->curY_2->setNum(y-ui->lblimage_1->y());
    // ui->Fvalue_2->setNum(meandt[x][y]);
 }
// qDebug()<<"Mouse position="<<x<<"\n";
// qDebug()<<"Mouse position="<<y<<"\n";
}

void MainWindow::mousePressEvent(QMouseEvent *e)
{
 int x=e->pos().x();
 int y=e->pos().y();
 if(x>=0&&x<c&&y>=0&&y<r)
 {

 }
 else if(x>=r&&x<ui->lblimage_1->x());
 /*else if(x>=ui->lblimage_1->x()&&x<(ui->lblimage_1->x()+c1)&&y>=0)
 {
     qDebug()<<"Inside Else If";
     ui->curX_2->setNum(x-ui->lblimage_1->x());
     ui->curY_2->setNum(y-ui->lblimage_1->y());
    // ui->Fvalue_2->setNum(meandt[x][y]);
 }*/
if(x<c1&&y<r1)
qDebug()<<"Mouse position="<<x<<","<<y<<"Distance="<<DR[x][y]<<"Real normalized DT="<<realNDR[x][y]<<"SDTR="<<sdtr[x][y]<<","<<colorsdtr[x][y];
}

void linedrawing(int x0,int y0,int x1,int y1)
{
    // calculate dx & dy
       int dx =x1-x0;
       int dy =y1-y0;

       // calculate steps required for generating pixels
       int steps = abs(dx) > abs(dy) ? abs(dx) : abs(dy);

       // calculate increment in x & y for each steps
       float Xinc = dx / (float) steps;
       float Yinc = dy / (float) steps;

       // Put pixel for each step
       float X =x0;
       float Y =y0;
       for (int i = 0; i <= steps; i++)
       {
           int ox=(int)round(X)+xcentre;
           int oy=ycentre-(int)round(Y);
           a1[ox][oy]=50;  // put pixel at (X,Y)
           X += Xinc;           // increment in x at each step
           Y += Yinc;           // increment in y at each step          // for visualization of line-                                // generation step by step
       }
}

void MainWindow::draw_image1(unsigned short **out, QLabel *labelpointer)
{
    int i,j;

    unsigned short val;

    QImage image1(c1,r1,QImage::Format_RGB888);

    for(j=0;j<r1;j++)
    {
        for(i=0;i<c1;i++)
        {
            val=out[i][j];
            image1.setPixel(i,j,qRgb(val,val,val));
            if(val)image1.setPixel(i,j,qRgb(0,0,0));
            if(!val)image1.setPixel(i,j,qRgb(255,255,255));
            if(val==1000)image1.setPixel(i,j,qRgb(255,0,0));
            //if(val)
                //image1.setPixel(i,j,qRgb(127,127,127));
            //else image1.setPixel(i,j,qRgb(255,255,255));
            //if(slope1[i][j])image1.setPixel(i,j,qRgb(0,0,0));
            //if(boundary[i][j])image1.setPixel(i,j,qRgb(0,0,255));
            //if(i==306&&j==203)image1.setPixel(i,j,qRgb(0,0,255));
            //if(boundary[i][j]==10)image1.setPixel(i,j,qRgb(255,255,0));
            //if(i==xleft||j==ydown||i==yux)image1.setPixel(i,j,qRgb(255,0,0));
            //if(ndr1[i][j]>230)image1.setPixel(i,j,qRgb(255,0,0));
        }
    }

   /* if(ui->drawline_2->isChecked())
    {
       if(p1!=p2)
       {
          for(i=ui->lblimage_1->x();i<=ui->lblimage_1->x()+p2;i++)
          {
           image1.setPixel(i,q1,qRgb(255,255,0));
          }
       }
       else
       {
           for(i=ui->lblimage_1->y()+q1;i<=q2+ui->lblimage_1->y();i++)
           {
               image1.setPixel(p1,i,qRgb(255,255,0));
           }
       }
    }*/
        labelpointer->adjustSize();
        labelpointer->setMinimumHeight(r1);
        labelpointer->setMinimumWidth(c1);
        //labelpointer->setPixmap(QPixmap::fromImage(image1).scaled(ui->lblimage_1->width(),ui->lblimage_1->height(),Qt::KeepAspectRatio));
        labelpointer->setPixmap(QPixmap::fromImage(image1));
}

void MainWindow::colorcode1(unsigned short **array,int cth,QLabel *labelpointer)
{
    int red=0,green=0,blue=0,i,j,hu,saturation=1;
    QImage image1(c1,r1,QImage::Format_RGB888);
    double del=(360-cth)/4;
    for(j=0;j<r1;j++)
        {
            for(i=0;i<c1;i++)
            {
                red=0;green=0;blue=0;
                if(array[i][j])
                {
                    hu=array[i][j];
                    if(hu<=cth){

                            blue=(hu/(double)cth)*255;
                            if(ui->blackBG->isChecked())
                            {
                                blue=0;
                            }
                            //qDebug()<<"Value of Hu="<<hu<<","<<"Value of Blue="<<blue;
                    }

                    if(hu>cth&&hu<=(cth+del)){

                            blue=255*saturation;
                            green=((hu-cth)/del)*255*saturation;//+255*(1-saturation));
                            red=0;
                    }
                    if(hu>(cth+del)&&hu<=(cth+2*del)){
                        blue=(((cth+2*del)-hu)/del)*255*saturation;//255*(1-saturation);
                        green=255*saturation;
                        red=0;
                    }
                    if(hu>(cth+2*del)&&hu<=(cth+3*del)){
                        blue=0;
                        green=255*saturation;
                        red=((hu-(cth+2*del))/del)*255*saturation;//+255*(1-saturation);
                    }
                    if(hu>(cth+3*del)&&hu<=360){
                        blue=0;//255*(1-saturation);
                        green=((360.0-hu)/del)*255*saturation;//+255*(1-saturation);
                        red=255*(saturation);
                    }
                }
                image1.setPixel(i,j,qRgb(red,green,blue));
                //if(!red&&!blue&&!green&&a[i][j])image1.setPixel(i,j,qRgb(255,255,255));

                //if(slope1[i][j])image1.setPixel(i,j,qRgb(0,0,0));
                //if(i==306&&j==203)image1.setPixel(i,j,qRgb(255,255,255));
                //if(i==298&&j==211)image1.setPixel(i,j,qRgb(255,255,255));
                //if(i==318&&j==282)image1.setPixel(i,j,qRgb(255,255,255));
                if(!a[i][j])image1.setPixel(i,j,qRgb(255,255,255));
                if(ndr2[i][j]==1000)image1.setPixel(i,j,qRgb(255,255,255));
                if(sdtr2[i][j]==1000)image1.setPixel(i,j,qRgb(255,255,255));
            }
        }


        labelpointer->adjustSize();
        labelpointer->setMinimumHeight(r1);
        labelpointer->setMinimumWidth(c1);
        labelpointer->setPixmap(QPixmap::fromImage(image1));
        //labelpointer->setPixmap(QPixmap::fromImage(image1).scaled(ui->lblimage_1->width(),ui->lblimage_1->height(),Qt::KeepAspectRatio));
}

void MainWindow::on_colorEDT_stateChanged(int arg1)
{
    if(ui->colorEDT->isChecked())
    {
       colorcode1(colorEDT,0,ui->lblimage_1);
    }
    else
    draw_image1(nedt,ui->lblimage_1);
}

void saveProfile(unsigned short **arr, char *s)
{
    FILE *fp;
    fp=fopen(s,"wb");
    for(int j=0;j<r;j++)
    {
        for(int i=0;i<c;i++)
        {
            fprintf(fp,"%d,",arr[i][j]);
        }
        fprintf(fp,"%c",'\n');
    }
    fclose(fp);
}

void saveProfile(double **arr, char *s)
{
    FILE *fp;
    fp=fopen(s,"wb");
    for(int j=0;j<r;j++)
    {
        for(int i=0;i<c;i++)
        {
            fprintf(fp,"%f,",arr[i][j]);
        }
        fprintf(fp,"%c",'\n');
    }
    fclose(fp);
}

void calculate_EDT()
{
    //qDebug()<<"Inside EDT";
    int i,j;
    bool flag=true;
    double mini=DBL_MAX,maxi=0.0;
    for(j=0;j<r1;j++)
    {
        for(i=0;i<c1;i++)
        {
           if(a[i][j])
           {
            DR[i][j]=DBL_MAX;
            NN1[i][j].x=-1;
            NN1[i][j].y=-1;
           }
           else
           {
               DR[i][j]=0.0;
               NN1[i][j].x=i;
               NN1[i][j].y=j;
           }
        }
    }
    //qDebug()<<"Initialization Done";

    do
    {
        //Forward Pass
        flag=false;
        for(j=1;j<r1-1;j++)
        {
           for(i=1;i<c1-1;i++)
           {
              if(a[i][j])
              {
                  for(int n=0;n<9;n++)
                  {
                      int p=i+npp[n][0];
                      int q=j+npp[n][1];
                      if(p==i&&q==j)continue;
                      int x1=NN1[p][q].x;
                      int y1=NN1[p][q].y;
                      if(x1==-1&&y1==-1)continue;
                      for(int n1=0;n1<9;n1++)
                      {
                          int p1=x1+npp[n1][0];
                          int q1=y1+npp[n1][1];
                          //if(a[p1][q1])continue;
                          double dis=sqrt((i-p1)*(i-p1)+(j-q1)*(j-q1));
                          if(dis<DR[i][j])
                          {
                               DR[i][j]=dis;
                               NN1[i][j].x=NN1[p1][q1].x;
                               NN1[i][j].y=NN1[p1][q1].y;
                               flag=true;
                          }
                      }
                      //if(NN1[i][j].x!=x1||NN1[i][j].y!=y1);//qDebug()<<"Points selected from neighborhood";
                      //else if(NN1[i][j].x==x1&&NN1[i][j].y==y1)qDebug()<<"Centre point selected";
                  }

                  //if(!boundary[NN1[i][j].x][NN1[i][j].y])qDebug()<<"Shortest distance achieved from outside boundary";
              }
           }
        }

        //Backward Pass

        for(j=r1-2;j>=1;j--)
        {
           for(i=c1-2;i>=1;i--)
           {
               if(a[i][j])
               {
                   for(int n=0;n<9;n++)
                   {
                       int p=i+npp[n][0];
                       int q=j+npp[n][1];
                       if(p==i&&q==j)continue;
                       int x1=NN1[p][q].x;
                       int y1=NN1[p][q].y;
                       if(x1==-1&&y1==-1)continue;
                       for(int n1=0;n1<9;n1++)
                       {
                           int p1=x1+npp[n1][0];
                           int q1=y1+npp[n1][1];
                           //if(a[p1][q1])continue;
                           double dis=sqrt((i-p1)*(i-p1)+(j-q1)*(j-q1));
                           if(dis<DR[i][j])
                           {
                                DR[i][j]=dis;
                                NN1[i][j].x=NN1[p1][q1].x;
                                NN1[i][j].y=NN1[p1][q1].y;
                                flag=true;
                           }
                       }
//                       if(NN1[i][j].x!=x1||NN1[i][j].y!=y1)
//                       qDebug()<<"Points selected from neighborhood";
//                       else if(NN1[i][j].x==x1&&NN1[i][j].y==y1); //qDebug()<<"Centre point selected";

                      // if(!boundary[NN1[i][j].x][NN1[i][j].y])qDebug()<<"Shortest distance achieved from outside boundary";
                   }
               }
           }
        }

    }while(flag);

    for(j=0;j<r1;j++)
    {
        for(i=0;i<c1;i++)
        {
            EDT[i][j]=(unsigned short)round(DR[i][j]);
        }
    }

    for(j=0;j<r1;j++)
    {
        for(i=0;i<c1;i++)
        {
             if(DR[i][j]<mini&&DR[i][j]>0.0)mini=DR[i][j];
             if(DR[i][j]>maxi)maxi=DR[i][j];
        }
    }
    //qDebug()<<"Maximum euclidean distance"<<maxi;;
    for(j=0;j<r1;j++)
    {
        for(i=0;i<c1;i++)
        {
                 if(DR[i][j]>0.0)
                 {
                     double val=((DR[i][j]-mini)/(maxi-mini))*255;
                     double val1=((DR[i][j]-mini)/(maxi-mini))*360;
                     val=round(val);
                     val1=round(val1);
                     nedt[i][j]=(unsigned short)val;
                     colorEDT[i][j]=(unsigned short)val1;
                 }
                 else
                 {
                     nedt[i][j]=0;
                     colorEDT[i][j]=0;
                 }
        }
    }

}

void MainWindow::on_EDTOLD_clicked()
{
    //qDebug()<<"Inside EDT";
    int i,j,x,y,itr=0,maxdtx,maxdty;
    bool flag=true;
    double mini=DBL_MAX,maxi=0.0;
    for(j=0;j<r1;j++)
    {
        for(i=0;i<c1;i++)
        {
           if(a[i][j])
           {
            DR[i][j]=DBL_MAX;
            NN1[i][j].x=-1;
            NN1[i][j].y=-1;
           }
           else
           {
               DR[i][j]=0.0;
               NN1[i][j].x=i;
               NN1[i][j].y=j;
           }
        }
    }
    //qDebug()<<"Initialization Done";

    do
    {
        //Forward Pass
        flag=false;
        for(j=1;j<r1-1;j++)
        {
           for(i=1;i<c1-1;i++)
           {
              if(a[i][j])
              {
                  for(int n=0;n<9;n++)
                  {
                      int p=i+npp[n][0];
                      int q=j+npp[n][1];
                      x=NN1[p][q].x;
                      y=NN1[p][q].y;
                      if(x==-1&&y==-1)continue;
                      double dis=sqrt((i-x)*(i-x)+(j-y)*(j-y));
                      if(dis<DR[i][j])
                      {
                         DR[i][j]=dis;
                         NN1[i][j].x=NN1[p][q].x;
                         NN1[i][j].y=NN1[p][q].y;
                         flag=true;
                      }
                  }
                  //int xx=NN1[i][j].x;
              }
           }
        }

        //Backward Pass

        for(j=r1-2;j>=1;j--)
        {
           for(i=c1-2;i>=1;i--)
           {
               if(a[i][j])
               {
                   for(int n=0;n<9;n++)
                   {
                       int p=i+npp[n][0];
                       int q=j+npp[n][1];
                       x=NN1[p][q].x;
                       y=NN1[p][q].y;
                       if(x==-1&&y==-1)continue;
                       double dis=sqrt((i-x)*(i-x)+(j-y)*(j-y));
                       if(dis<DR[i][j])
                       {
                          DR[i][j]=dis;
                          NN1[i][j].x=NN1[p][q].x;
                          NN1[i][j].y=NN1[p][q].y;
                          flag=true;
                       }
                   }
               }
           }
        }

        itr++;
        //qDebug()<<itr<<"iteration complete";

    }while(flag);

    for(j=0;j<r1;j++)
    {
        for(i=0;i<c1;i++)
        {
            EDT[i][j]=(unsigned short)round(DR[i][j]);
        }
    }

    int ws=0;
    for(j=0;j<r1;j++)
    {
        for(i=0;i<c1;i++)
        {
             double sum=0.0;
             int count=0;

             if(DR[i][j]>0.0)
             {
               for(int q=j-ws;q<=j+ws;q++)
               {
                   for(int p=i-ws;p<=i+ws;p++)
                   {
                       if(DR[p][q]>0.0)
                       {
                           sum=sum+DR[p][q];
                           count++;
                       }
                   }
               }

               avgDR[i][j]=sum/count;
             }
             else avgDR[i][j]=0;
        }
    }

    for(j=0;j<r1;j++)
    {
        for(i=0;i<c1;i++)
        {
             if(avgDR[i][j]<mini&&avgDR[i][j]>0.0)mini=avgDR[i][j];
             if(avgDR[i][j]>maxi&&avgDR[i][j]<2000)
             {
                 maxi=avgDR[i][j];
                 maxdtx=i;
                 maxdty=j;
             }
        }
    }
    maxglobalDT=maxi;
    qDebug()<<"Maximum euclidean distance"<<maxglobalDT<<","<<maxdtx<<" "<<maxdty;
    for(j=0;j<r1;j++)
    {
        for(i=0;i<c1;i++)
        {
                 if(avgDR[i][j]>0.0)
                 {
                     DR1[i][j]=(avgDR[i][j]-mini)/(maxi-mini);
                     double val=((avgDR[i][j]-mini)/(maxi-mini))*255;
                     double val1=((avgDR[i][j]-mini)/(maxi-mini))*360;
                     val=round(val);
                     val1=round(val1);
                     nedt[i][j]=(unsigned short)val;
                     colorEDT[i][j]=(unsigned short)val1;
                 }
                 else
                 {
                     nedt[i][j]=0;
                     colorEDT[i][j]=0;
                     DR1[i][j]=0;
                 }
        }
    }

    qDebug()<<"draw with nedtttttttttttttt";
    draw_image1(nedt,ui->lblimage_1);
}

void MainWindow::on_gradient_clicked()
{
    //compute_gradx5(avgDR);
    //compute_grady5(avgDR);
    compute_gradx(avgDR);
    compute_grady(avgDR);
    compute_grad();
    draw_image1(prewitGrad,ui->lblimage_1);
}

void compute_gradx5(double **DR)
{
    int i,j,p,q,n,ws=2;
    double realsum=0.0;
    for(j=0;j<r1;j++)
        {
            for(i=0;i<c1;i++)
            {
                    realsum=0.0;
                    n=0;
                    //if(DR[i][j]>0.0)
                    {
                        for(q=j-ws;q<=j+ws;q++)
                        {
                            for(p=i-ws;p<=i+ws;p++)
                            {
                                if(p<0||p>=c1||q<0||q>=r1)continue;
                                if(DR[p][q]>0.0)
                                    realsum=realsum+(DR[p][q]*gx5[n]);
                                else realsum=realsum+(DRN[p][q]*gx5[n]);
                                n++;
                            }
                        }
                    }
                gradxp[i][j]=realsum;
                //avgGradxp[i][j]=realsum;
            }
        }
}

void compute_gradx(double **DR)
{
    int i,j,p,q,n,count,ws;
    double realsum=0.0;
    for(j=0;j<r1;j++)
        {
            for(i=0;i<c1;i++)
            {
                realsum=0.0;
                //if(DR[i][j]>0.0)
                {
                    for(n=0;n<9;n++)
                    {
                        p=i+npp[n][0];
                        q=j+npp[n][1];
                        if(p==i&&q==j);
                        else if(p>=0&&p<c1&&q>=0&&q<r1)
                        {
                            if(DR[p][q]>0.0)
                                realsum=realsum+(DR[p][q]*gx[n]);
                            else realsum=realsum+(DRN[p][q]*gx[n]);
                        }
                    }
                }
                gradxp[i][j]=realsum;
                //avgGradxp[i][j]=realsum;
            }
        }
}

void compute_grady5(double **DR)
{
    int i,j,p,q,n,ws=2;
    double realsum=0.0;
    for(j=0;j<r1;j++)
        {
            for(i=0;i<c1;i++)
            {
                realsum=0.0;
                n=0;
                //if(DR[i][j]>0.0)
                {
                    for(q=j-ws;q<=j+ws;q++)
                    {
                        for(p=i-ws;p<=i+ws;p++)
                        {
                            if(p<0||p>=c1||q<0||q>=r1)continue;
                            if(DR[p][q]>0.0)
                                realsum=realsum+(DR[p][q]*gy5[n]);
                            else realsum=realsum+(DRN[p][q]*gy5[n]);
                            n++;
                        }
                    }
                }

                gradyp[i][j]=realsum;
                //avgGradyp[i][j]=realsum;
            }
        }
}

void compute_grady(double **DR)
{
    int i,j,p,q,n,count,ws;
    double realsum=0.0;
    for(j=0;j<r1;j++)
        {
            for(i=0;i<c1;i++)
            {
                realsum=0.0;
                //if(avgDR[i][j]>0.0)
                {
                    for(n=0;n<9;n++)
                    {
                        p=i+npp[n][0];
                        q=j+npp[n][1];
                        if(p==i&&q==j);
                        else if(p>=0&&p<c1&&q>=0&&q<r1)
                        {
                            if(DR[p][q]>0.0)
                            {
                                realsum=realsum+(DR[p][q]*gy[n]);
                            }

                            else
                            {
                                realsum=realsum+(DRN[p][q]*gy[n]);
                            }
                        }
                    }
                }

                gradyp[i][j]=realsum;
                //avgGradyp[i][j]=realsum;
            }
        }
}

void compute_grad()
{
    int i,j,p,q,ws,count;
    double g,max1=0.0,val,val1,realsum;
    unsigned short max=0;

    for(j=1;j<r1-1;j++)
        {
            for(i=1;i<c1-1;i++)
            {
                realsum=0.0;
                count=0;
                //if(avgDR[i][j]>0.0)
                {
                  if(gradxp[i][j]==0)continue;
                  if(boundary[i][j]==1)ws=0;
                  else ws=0;

                  for(q=j-ws;q<=j+ws;q++)
                  {
                      for(p=i-ws;p<=i+ws;p++)
                      {
                          if(p<0||p>=c1||q<0||q>=r1)continue;
                          //if(avgDR[p][q]>0.0)
                          {
                              realsum=realsum+gradxp[p][q];
                              count++;
                          }
                      }
                  }
                  realsum=realsum/(double)count;
                }
                avgGradxp[i][j]=realsum;
            }
        }


    for(j=1;j<r1-1;j++)
        {
            for(i=1;i<c1-1;i++)
            {
                realsum=0.0;
                count=0;
                //if(avgDR[i][j]>0.0)
                {
                  if(gradyp[i][j]==0)continue;
                  if(boundary[i][j]==1)ws=0;
                  else ws=0;
                  for(q=j-ws;q<=j+ws;q++)
                  {
                      for(p=i-ws;p<=i+ws;p++)
                      {
                        if(p<0||p>=c1||q<0||q>=r1)continue;
                        //if(avgDR[p][q]>0.0)
                        {
                            realsum=realsum+gradyp[p][q];
                            count++;
                        }
                      }
                  }
                  realsum=realsum/(double)count;
                }
                avgGradyp[i][j]=realsum;
            }
        }
    for(j=1;j<r1-1;j++)
    {
        for(i=1;i<c1-1;i++)
        {
               if(a[i][j])
               {
                    g=sqrt((avgGradxp[i][j]*avgGradxp[i][j])+(avgGradyp[i][j]*avgGradyp[i][j]));
                    realprewit[i][j]=g;
                    if(realprewit[i][j]>max1)
                    {
                        max1=realprewit[i][j];
                        gxi=i;
                        gyj=j;
                    }
               }
               else realprewit[i][j]=0;
        }
    }

    qDebug()<<"maximum gradient="<<max1<<gxi<<gyj;

    for(j=0;j<r1;j++)
    {
        for(i=0;i<c1;i++)
        {

                val=(realprewit[i][j]/max1)*255;
                val1=(realprewit[i][j]/max1)*360;
                realprewit1[i][j]=val1;
                prewitGrad[i][j]=(unsigned short)round(val);
                colorprewittgrad[i][j]=(unsigned short)round(val1);
                if(a[i][j]&&colorprewittgrad[i][j]==0)colorprewittgrad[i][j]=1;
        }
    }
}


void MainWindow::on_colorGrad_stateChanged(int arg1)
{
    if(ui->colorGrad->isChecked())
    {
        colorcode1(colorprewittgrad,0,ui->lblimage_1);
    }
    else draw_image1(prewitGrad,ui->lblimage_1);
}

void MainWindow::on_gradDirection_clicked()
{
   int i,j,gc=0,ws;
   double rad,degree,minangle=100000.0,maxangle=-100000.0,sum=0.0,grad;
   for(j=0;j<r1;j++)
   {
       for(i=0;i<c1;i++)
       {
            if(avgDR[i][j]>0.0)
            {
                if(avgGradxp[i][j]==0&&avgGradyp[i][j]==0)
                {
                    direction1[i][j]=1000;
                    //qDebug()<<"true ridge point";
                    continue;
                }
                if(avgGradxp[i][j]==0)
                {
                        if(avgGradyp[i][j]>0)
                        {
                            direction[i][j]=90.0;
                            direction1[i][j]=90.0;
                        }
                        else
                        {
                            direction[i][j]=270.0;
                            direction1[i][j]=270.0;
                        }
                }
                else if(avgGradyp[i][j]==0)
                {
                    if(avgGradxp[i][j]>0)
                    {
                        direction[i][j]=0;
                        direction1[i][j]=0;
                    }
                    else
                    {
                        direction[i][j]=180.0;
                        direction1[i][j]=180.0;
                    }
                }
                else if(avgGradxp[i][j]>0&&avgGradyp[i][j]>0)
                {
                    rad=asin((avgGradyp[i][j]/realprewit[i][j]));
                    //rad=atan((avgGradyp[i][j]/realprewit[i][j]));
                    degree=(180.0*rad)/M_PI;
                    //qDebug()<<"deree value=====>"<<degree<<",";
                    direction[i][j]=degree;
                    direction1[i][j]=degree;
                }
                else if(avgGradxp[i][j]<0&&avgGradyp[i][j]<0)
                {
                    rad=asin((avgGradyp[i][j]/realprewit[i][j]));
                    //rad=atan((avgGradyp[i][j]/realprewit[i][j]));
                    degree=(180.0*rad)/M_PI;
                    //qDebug()<<"deree value=====>"<<degree<<",";
                    direction[i][j]=180.0-degree;
                    direction1[i][j]=180.0-degree;
                    //direction[i][j]=degree;
                    //direction1[i][j]=degree;
                }
                else if(avgGradxp[i][j]<0&&avgGradyp[i][j]>0)
                {
                    rad=acos((avgGradxp[i][j]/realprewit[i][j]));
                    //rad=atan((avgGradxp[i][j]/realprewit[i][j]));
                    degree=(180.0*rad)/M_PI;
                    //qDebug()<<"deree value=====>"<<degree<<",";
                    //direction[i][j]=180.0+degree;
                    //direction1[i][j]=180.0+degree;
                    direction[i][j]=degree;
                    direction1[i][j]=degree;
                }
                else if(avgGradxp[i][j]>0&&avgGradyp[i][j]<0)
                {
                    rad=acos((avgGradxp[i][j]/realprewit[i][j]));
                    //rad=atan((avgGradxp[i][j]/realprewit[i][j]));
                    degree=(180.0*rad)/M_PI;
                    //qDebug()<<"degree value======>"<<degree<<","<<360.0-degree;
                    direction[i][j]=360.0-degree;
                    direction1[i][j]=360.0-degree;
                    //direction[i][j]=degree;
                    //direction1[i][j]=degree;
                }
            }
       }
   }

   for(j=0;j<r1;j++)
   {
       for(i=0;i<c1;i++)
       {
           if(direction1[i][j]>=357) direction1[i][j]=0;
           if(direction1[i][j]>=179&&direction1[i][j]<=183.5)direction1[i][j]=180.0;
           if(direction1[i][j]>180.0&&direction1[i][j]!=1000)direction1[i][j]=direction1[i][j]-180.0;
           //if(direction[i][j]>180.0)direction[i][j]=direction[i][j]-180.0;
           direction2[i][j]=round(direction1[i][j]);
       }
   }

//   for(j=0;j<r1;j++)
//   {
//       for(i=0;i<c1;i++)
//       {
//            if(avgGradxp[i][j]>0&&avgGradyp[i][j]>0)
//            {
//                if(direction1[i][j]>90.0)
//                {
//                direction1[i][j]=180.0-direction1[i][j];
//                direction2[i][j]=round(direction1[i][j]);
//                }
//            }
//       }
//   }
  // draw_image1(direction2,ui->lblimage_1);

  /*ws=ui->AvgWindow->value();
  if(ws>0)
  {
      for(j=0;j<r1;j++)
      {
          for(i=0;i<c1;i++)
          {
                if(avgDR[i][j]>0.0)
                {
                    sum=0.0;
                    double os;
                    gc=0;
                    for (int q=j-ws;q<=j+ws;q++)
                    {
                        for (int p=i-ws;p<=i+ws;p++)
                        {
                               if(avgDR[p][q]>0.0)
                               {
                                   os=direction[p][q];
                                   sum=sum+os;
                                   gc++;
                               }
                         }
                      }
                  }
          }
          if(gc>0)
          direction1[i][j]=sum/(double)gc;
       }
   }*/

//  for(j=0;j<r1;j++)
//  {
//      for(i=0;i<c1;i++)
//      {
//         if(direction1[i][j]<0.0000000001)direction1[i][j]=0;
//         if(direction1[i][j]>(180.0-0.0000001)&&direction1[i][j]<(180.0+0.0000001))direction1[i][j]=180.0;
//         if(direction1[i][j]>(360.0-0.0000001)&&direction1[i][j]<(360.0+0.0000001))direction1[i][j]=360.0;
//      }
//  }

   for(j=0;j<r1;j++)
   {
       for(i=0;i<c1;i++)
       {
          if(direction1[i][j]<minangle)minangle=direction1[i][j];
          if(direction1[i][j]>maxangle)maxangle=direction1[i][j];
       }
   }


  /* FILE *fp;
   fp=fopen("GradientDirection.csv","wb");
   for(int j=0;j<r;j++)
   {
       for(int i=0;i<c;i++)
       {
           fprintf(fp,"%f,",direction1[i][j]);
       }
       fprintf(fp,"%c",'\n');
   }
   fclose(fp);*/

   //qDebug()<<"Minimum gradient angle="<<minangle;
   //qDebug()<<"Maximum gradient angle="<<maxangle;
   for(j=0;j<r1;j++)
   {
       for(i=0;i<c1;i++)
       {
         colordirection[i][j]=(unsigned short)round(direction1[i][j]);
       }
   }

   anglecolorcode(colordirection,0,ui->lblimage_1);
}

void MainWindow::anglecolorcode(unsigned short **array,int cth,QLabel *labelpointer)
{
    int red=0,green=0,blue=0,i,j,hu,saturation=1;
    QImage image1(c1,r1,QImage::Format_RGB888);
    for(j=0;j<r1;j++)
        {
            for(i=0;i<c1;i++)
            {
                red=0;green=0;blue=0;
                if(avgDR[i][j]>0.0)
                {
                    hu=array[i][j];

                    if(hu>=0&&hu<=60){

                            red=((60-hu)/60.0)*255*saturation;
                            green=(hu/60.0)*255*saturation;
                            blue=0;
                    }
                    if(hu>=60&&hu<=120){
                        green=((120-hu)/60.0)*255*saturation;
                        blue=((hu-60)/60.0)*255*saturation;
                        red=0;
                    }
                    if(hu>=120&&hu<=180){
                        blue=((180-hu)/60.0)*255*saturation;
                        red=((hu-120)/60.0)*255*saturation;
                        green=0;
                    }
                    /*if(hu>=180&&hu<=240)
                    {
                        red=((240-hu)/60.0)*255*saturation;
                        green=((hu-180)/60.0)*255*saturation;
                        blue=0;
                    }
                    if(hu>=240&&hu<=300)
                    {
                        green=((300-hu)/60.0)*255*saturation;
                        blue=((hu-240)/60.0)*255*saturation;
                        red=0;
                    }
                    if(hu>=300&&hu<=360)
                    {
                        blue=((360-hu)/60.0)*255*saturation;
                        red=((hu-300)/60.0)*255*saturation;
                        green=0;
                    }*/
                }
                image1.setPixel(i,j,qRgb(red,green,blue));
                //if(!red&&!blue&&!green&&a[i][j])image1.setPixel(i,j,qRgb(255,255,255));
                if(!a[i][j])image1.setPixel(i,j,qRgb(255,255,255));
            }
        }


        labelpointer->adjustSize();
        labelpointer->setMinimumHeight(r1);
        labelpointer->setMinimumWidth(c1);
        labelpointer->setPixmap(QPixmap::fromImage(image1));
        //labelpointer->setPixmap(QPixmap::fromImage(image1).scaled(ui->lblimage_1->width(),ui->lblimage_1->height(),Qt::KeepAspectRatio));
}

void MainWindow::on_drawGradLine_clicked()
{
    int i,j;


    for (j=147;j<148;j++)
    {
       for(i=354;i<355;i++)
       {
            if(avgDR[i][j]>0.0)
            {
                gdtmax=-10000.0;
                gdtmin=10000.0;
                //qDebug()<<"Direction==========>"<<direction1[i][j];
                qDebug()<<"Old gradline is called"<<i<<j;
                geodesic(i,j);
                //Gradline(i,j);
            }
            //else qDebug()<<"AvgDR zero"<<i<<j;
       }
    }

   /*for (j=158;j<159;j++)
    {
       for(i=326;i<327;i++)
       {
            if(avgDR[i][j]>0.0)
            {
                gdtmax=-10000.0;
                gdtmin=10000.0;
                //qDebug()<<"Direction==========>"<<direction1[i][j];
                qDebug()<<"Old gradline is called"<<i<<j;
                geodesic2(i,j);
                //Gradline(i,j);
            }
            //else qDebug()<<"AvgDR zero"<<i<<j;
       }
    }*/

   /*for (j=157;j<158;j++)
    {
       for(i=327;i<328;i++)
       {
            if(avgDR[i][j]>0.0)
            {
                gdtmax=-10000.0;
                gdtmin=10000.0;
                //qDebug()<<"Direction==========>"<<direction1[i][j];
                qDebug()<<"Old gradline is called"<<i<<j;
                geodesic2(i,j);
                //Gradline(i,j);
            }
            //else qDebug()<<"AvgDR zero"<<i<<j;
       }
    }*/

    draw_image1(prewitGrad,ui->lblimage_1);

      FILE *fp;
      fp=fopen("SmoothnessOfGradientFlow.csv","wb");
      for(int j=0;j<r1;j++)
      {
        for(int i=0;i<c1;i++)
        {
            if(slope1[i][j])
            fprintf(fp,"%d,%d,%f\n",i,j,realdotproduct[i][j]);
        }
        //fprintf(fp,"%c",'\n');
      }
    fclose(fp);

}

void geodesic(int i,int j)
{
    int p,q,x,y,index=0,c,f=0,indexs=0;
    double ang,dotproduct,dth=0.41;
    p=i;
    q=j;
    while(p>=0&&p<c1&&q>=0&&q<r1&&
          avgDR[p][q]>gdtmax)
    {
            visited[p][q]=1;
            x=p;
            y=q;
            slope1[p][q]=255;
            ang=direction1[p][q];
            gdtmax=avgDR[p][q];
            if(ang==1000)
            {
                scaleMap[i][j]=avgDR[p][q];
                scaleMap1[i][j]=(unsigned short)round(avgDR[p][q]);
                return;
            }
            path[index].x=p;
            path[index].y=q;
            path[index].colorgrad=colorprewittgrad[p][q];
            path[index].direction=ang;
            index++;
        if(ang==90.0)
        {
            p=x;
            q=y+1;
            if(avgDR[x][y-1]>gdtmax)
            {
                p=x;
                q=y-1;
            }
        }

        else if(ang==0.0||ang==180.0)
        {
            q=y;
            p=x+1;
            if(x-1>=0&&avgDR[x-1][y]>gdtmax)
            {
                q=y;
                p=x-1;
            }
        }
        else if(ang>=0&&ang<22.5)
        {
           p=x+1;
           q=y;
           if(x-1>=0&&avgDR[x-1][y]>gdtmax)
           {
               q=y;
               p=x-1;
           }
        }
        else if(ang>=22.5&&ang<67.5)
        {
           p=x+1;
           q=y-1;
           if(x-1>=0&&avgDR[x-1][y+1]>gdtmax)
           {
               q=y+1;
               p=x-1;
           }
        }
        else if(ang>=67.5&&ang<112.5)
        {
           p=x;
           q=y-1;
           if(avgDR[x][y+1]>gdtmax)
           {
               q=y+1;
               p=x;
           }
        }
        else if(ang>=112.5&&ang<157.5)
        {
           p=x-1;
           q=y-1;
           if(avgDR[x+1][y+1]>gdtmax)
           {
               q=y+1;
               p=x+1;
           }
        }
        else if(ang>=157.5&&ang<181)
        {
           p=x-1;
           q=y;
           if(avgDR[x+1][y]>gdtmax)
           {
               q=y;
               p=x+1;
           }
        }
    }

    if(index>1)
    {
        c=0;
        f=0;
        ang=path[c].direction-path[c+1].direction;
        if(ang<0)ang=-ang;
        if(ang>90.0)ang=180.0-ang;
        dotproduct=path[c].colorgrad*path[c+1].colorgrad*cos((M_PI*ang)/180.0);
        dotproduct=dotproduct/(360.0*360.0);
        if(dotproduct>dth)
        {
            for(c=1;c<index-1;c++)
            {
                    ang=path[c].direction-path[c+1].direction;
                    if(ang<0)ang=-ang;
                    if(ang>90.0)ang=180.0-ang;
                    dotproduct=path[c].colorgrad*path[c+1].colorgrad*cos((M_PI*ang)/180.0);
                    dotproduct=dotproduct/(360.0*360.0);
                    if(dotproduct>dth)f=0;
                    if(dotproduct<=dth&&!f)
                    {
                        indexs=c;
                        f=1;
                    }
            }
        }
        else
        {
            f=1;
            for(c=1;c<index-1;c++)
            {
                    ang=path[c].direction-path[c+1].direction;
                    if(ang<0)ang=-ang;
                    if(ang>90.0)ang=180.0-ang;
                    dotproduct=path[c].colorgrad*path[c+1].colorgrad*cos((M_PI*ang)/180.0);
                    dotproduct=dotproduct/(360.0*360.0);
                    if(dotproduct>dth)f=0;
                    if(dotproduct<=dth&&!f)
                    {
                        indexs=c;
                        f=1;
                        //break;
                    }
            }
        }

        if(f==1)
        {
            if(path[indexs+1].x==318&&path[indexs+1].y==282)qDebug()<<"highest distance point found-"<<i<<j;
            gdtmax=avgDR[path[indexs+1].x][path[indexs+1].y];
        }
    }
    scaleMap[i][j]=gdtmax;
    scaleMap1[i][j]=(unsigned short)round(scaleMap[i][j]);
}

void MainWindow::on_NEDT_clicked()
{
  int i,j;
  double sig;
  clock_t t;
  t = clock();
  qDebug()<<"Time starts for NEDT calculation.....";
  for(j=0;j<r1;j++)
  {
      for(i=0;i<c1;i++)
      {
           if(avgDR[i][j]>0.0)
           {

                    gdtmax=-10000.0;
                    gdtmin=0;
                    geodesic(i,j);
                    realNDR[i][j]=1/(gdtmax-gdtmin);
                    NDR[i][j]=(unsigned short)round((360.0)/(gdtmax-gdtmin));
           }
           else
           {
               realNDR[i][j]=0;
               NDR[i][j]=0;
               scaleMap[i][j]=0;
               scaleMap1[i][j]=0;
           }
      }
  }
  /*double maxsig=0.0;
  int ci,cj;
  for(j=0;j<r1;j++)
  {
      for(i=0;i<c1;i++)
      {
            //sig=realNDR[i][j]/sqrt(1+(realNDR[i][j]*realNDR[i][j]/DR[i][j]));
          if(DR1[i][j]>0.0)
          {
            sig=(realNDR[i][j]*realNDR[i][j]);
            sig=sig*DR1[i][j];
            realNDR1[i][j]=sig;
            //NDR1[i][j]=round(sig*360.0);
            if(sig>maxsig&&boundary[i][j]!=100)
            {
              maxsig=sig;
              ci=i;cj=j;
            }
          }
      }
  }


  qDebug()<<"NEDT Maxsig="<<maxsig<<ci<<cj<<realNDR1[ci][cj];
  for(j=0;j<r1;j++)
  {
      for(i=0;i<c1;i++)
      {
          //if(realNDR1[i][j]==maxsig)qDebug()<<"maximum found in realNDR";
          NDR1[i][j]=(realNDR1[i][j]*360)/maxsig;
      }
  }
  //qDebug()<<"Maximum of sigmoid="<<maxsig;*/
  t = clock() - t;
  double time_taken = ((double)t)/CLOCKS_PER_SEC; // in seconds
  qDebug()<<"total time taken for nedt="<<time_taken;

  colorcode1(NDR,0,ui->lblimage_1);
  //colorcode1(NDR1,0,ui->lblimage_1);
  /*int m=0;
  for(j=0;j<r1;j++)
  {
      for(i=0;i<c1;i++)
      {
          if(NDR1[i][j]>m)
          {
              m=NDR1[i][j];
          }

      }
  }*/

  //qDebug()<<"MAXXXXXXXXXXXXXXXXXXXXXXXXX="<<m;
}

void MainWindow::on_CCL_clicked()
{
    int i,j,maxc=0,maxci;
    for (j=1;j<r1-1;j++)
    {
        for (i=1;i<c1-1;i++)
        {
            if(colorprewittgrad1[i][j])
            {
               skel1[i][j]=1;
            }
            else
            skel1[i][j]=0;
        }
    }
    cc=1;
    int ccc=0;
    for (j=1;j<r1-1;j++)
    {
        for (i=1;i<c1-1;i++)
        {
            if(skel1[i][j])ccc++;
            if(skel1[i][j]==1)
            {
               cc++;
               dfs(i,j);
            }
        }
    }
    qDebug()<<"total number of components="<<cc<<ccc<<cc1;

    componentcount=(unsigned short *)calloc(sizeof(unsigned short),c1);

    for(i=2;i<=cc;i++)componentcount[i]=0;
    for (j=0;j<r1;j++)
    {
        for (i=0;i<c1;i++)
        {
            componentcount[skel1[i][j]]=componentcount[skel1[i][j]]+1;
        }
    }
    for(i=2;i<=cc;i++)
    {
        if(componentcount[i]>maxc)
        {
            maxc=componentcount[i];
            maxci=i;
        }
    }
    qDebug()<<"Max Component Number="<<maxci;
    for (j=0;j<r1;j++)
    {
        for (i=0;i<c1;i++)
        {
            if(skel1[i][j]!=maxci)colorprewittgrad1[i][j]=0;
        }
    }
    colorcode1(colorprewittgrad1,0,ui->lblimage_1);
    //draw_image1(skel1,ui->lblimage_1);
}

void dfs(int i,int j)
{
   skel1[i][j]=cc;
   for(int q=j-1;q<=j+1;q++)
   {
       for(int p=i-1;p<=i+1;p++)
       {
            if(skel1[p][q]==1)
            {
                //qDebug()<<"Inside DFS recursive call";
                cc1++;
                dfs(p,q);
            }
       }
   }
}

void MainWindow::on_EDTN_clicked()
{
    //qDebug()<<"Inside EDT";
    int i,j,x,y;
    bool flag=true;
    double mini=DBL_MAX,maxi=0.0;
    for(j=0;j<r1;j++)
    {
        for(i=0;i<c1;i++)
        {
           if(!a[i][j])
           {
            DRN[i][j]=DBL_MAX;
            NN1[i][j].x=-1;
            NN1[i][j].y=-1;
           }
           else
           {
               DRN[i][j]=0.0;
               NN1[i][j].x=i;
               NN1[i][j].y=j;
           }
        }
    }
    //qDebug()<<"Initialization Done";

    do
    {
        //Forward Pass
        flag=false;
        for(j=0;j<r1;j++)
        {
           for(i=0;i<c1;i++)
           {
                if(!a[i][j])
                {
                  for(int n=0;n<9;n++)
                  {
                      int p=i+npp[n][0];
                      int q=j+npp[n][1];
                      if(p>=c1||p<0||q>=r1||q<0)continue;
                      x=NN1[p][q].x;
                      y=NN1[p][q].y;
                      if(x==-1&&y==-1)continue;
                      double dis=sqrt((i-x)*(i-x)+(j-y)*(j-y));
                      if(dis<DRN[i][j])
                      {
                         DRN[i][j]=dis;
                         NN1[i][j].x=NN1[p][q].x;
                         NN1[i][j].y=NN1[p][q].y;
                         flag=true;
                      }
                  }
              }
           }
        }

        //Backward Pass

        for(j=r1-1;j>=0;j--)
        {
           for(i=c1-1;i>=0;i--)
           {
               if(!a[i][j])
               {
                   for(int n=0;n<9;n++)
                   {
                       int p=i+npp[n][0];
                       int q=j+npp[n][1];
                       if(p>=c1||p<0||q>=r1||q<0)continue;
                       x=NN1[p][q].x;
                       y=NN1[p][q].y;
                       if(x==-1&&y==-1)continue;
                       double dis=sqrt((i-x)*(i-x)+(j-y)*(j-y));
                       if(dis<DRN[i][j])
                       {
                          DRN[i][j]=dis;
                          NN1[i][j].x=NN1[p][q].x;
                          NN1[i][j].y=NN1[p][q].y;
                          flag=true;
                       }
                   }
               }
           }
        }

    }while(flag);

    for(j=0;j<r1;j++)
    {
        for(i=0;i<c1;i++)
        {
            DRN[i][j]=-DRN[i][j];
        }
    }

  /*  for(j=0;j<r1;j++)
    {
        for(i=0;i<c1;i++)
        {
             if(DRN[i][j]<mini&&DRN[i][j]>0.0)mini=DRN[i][j];
             if(DRN[i][j]>maxi)maxi=DRN[i][j];
        }
    }
    qDebug()<<"Maximum euclidean distance"<<maxi;
    for(j=0;j<r1;j++)
    {
        for(i=0;i<c1;i++)
        {
                 if(DRN[i][j]>0.0)
                 {
                     double val=((DRN[i][j]-mini)/(maxi-mini))*255;
                     double val1=((DRN[i][j]-mini)/(maxi-mini))*360;
                     val=round(val);
                     val1=round(val1);
                     nedt[i][j]=(unsigned short)val;
                     colorEDT[i][j]=(unsigned short)val1;
                 }
                 else
                 {
                     nedt[i][j]=0;
                     colorEDT[i][j]=0;
                 }
        }
    }

    draw_image1(nedt,ui->lblimage_1);*/
}

void MainWindow::on_boundary_clicked()
{
    int i,j;
    for(j=1;j<r-1;j++)
    {
        for(i=1;i<c-1;i++)
        {
            if(a[i][j])
            {
              if(!a[i-1][j]||!a[i+1][j]||!a[i][j-1]||!a[i][j+1])
              {
                  boundary[i][j]=100;
              }
              else boundary[i][j]=0;
            }
        }
    }

   /* xleft=10000;
    xright=0;
    yup=0;
    ydown=10000;

    for(j=0;j<r1;j++)
    {
        for(i=0;i<c1;i++)
        {
                if(a[i][j])
                {
                    boundary[i][j]=10;
                    break;
                }
        }
    }

    for(j=0;j<r1;j++)
    {
        for(i=0;i<c1;i++)
        {
            if(a[i][j]&&i>xright)xright=i;
            if(a[i][j]&&i<xleft)
            {
                xleft=i;xlx=i;xly=j;
            }
            if(a[i][j]&&j>yup)
            {
                yup=j;yux=i;yuy=j;
            }
            if(a[i][j]&&j<ydown)ydown=j;
        }
    }*/

    draw_image1(a,ui->lblimage_1);
}

void MainWindow::on_nedtth_valueChanged(int arg1)
{
  int i,j;
  for(j=0;j<r1;j++)
  {
      for(i=0;i<c1;i++)
      {
          ndr2[i][j]=NDR[i][j];
      }
  }
  for(j=0;j<r1;j++)
  {
      for(i=0;i<c1;i++)
      {
          if(ndr2[i][j]<arg1)ndr2[i][j]=1000;
      }
  }
  colorcode1(ndr2,0,ui->lblimage_1);
}

void MainWindow::on_GT_valueChanged(int arg1)
{

    for(int j=0;j<r1;j++)
    {
        for(int i=1;i<c1;i++)
        {
            colorprewittgrad1[i][j]=colorprewittgrad[i][j];
        }
    }

   for(int j=0;j<r1;j++)
   {
       for(int i=1;i<c1;i++)
       {
           if(colorprewittgrad1[i][j]>arg1)colorprewittgrad1[i][j]=0;
       }
   }

   colorcode1(colorprewittgrad1,0,ui->lblimage_1);
}

void MainWindow::on_writeneighbor_clicked()
{
    int i=310,j=32,p,q;

    FILE *fp;
    fp=fopen("neighbour.txt","wb");

    for(q=j-1;q<=j+1;q++)
    {
        for(p=i-1;p<=i+1;p++)
        {
            fprintf(fp,"%f ",avgDR[p][q]);
        }

        fprintf(fp,"%c",'\n');
    }

    fprintf(fp,"%c",'\n');
    fprintf(fp,"%c",'\n');

    for(q=j-1;q<=j+1;q++)
    {
        for(p=i-1;p<=i+1;p++)
        {
            fprintf(fp,"%f ",direction1[p][q]);
        }

        fprintf(fp,"%c",'\n');
    }

    fprintf(fp,"%c",'\n');
    fprintf(fp,"%c",'\n');

    for(q=j-1;q<=j+1;q++)
    {
        for(p=i-1;p<=i+1;p++)
        {
            fprintf(fp,"%d ",colorprewittgrad[p][q]);
        }

        fprintf(fp,"%c",'\n');
    }

     fclose(fp);
}

void MainWindow::on_realndr_valueChanged(double arg1)
{
    int i,j;
    for(j=0;j<r1;j++)
    {
        for(i=0;i<c1;i++)
        {
            if(realNDR1[i][j]<arg1)NDR1[i][j]=0;
        }
    }
    colorcode1(NDR1,0,ui->lblimage_1);
}

void MainWindow::on_dotproduct_clicked()
{
    int i,j,p,q;
    double ang,dp;
    for(j=0;j<r1;j++)
    {
        for(i=0;i<c1;i++)
        {
            if(avgDR[i][j]>0)
            {
               ang=direction1[i][j];
               if(direction1[i][j]==1000)
               {
                   realdotproduct[i][j]=0;
                   dotproduct[i][j]=0;
                   continue;
               }
               gdtmax=avgDR[i][j];
               if(ang==90.0)
               {
                   p=i;
                   q=j+1;
                   if(avgDR[i][j-1]>gdtmax)
                   {
                       p=i;
                       q=j-1;
                   }
               }

               else if(ang==0.0||ang==180.0)
               {
                   q=j;
                   p=i+1;
                   if(i-1>=0&&avgDR[i-1][j]>gdtmax)
                   {
                       q=j;
                       p=i-1;
                   }
               }
               else if(ang>=0&&ang<22.5)
               {
                  p=i+1;
                  q=j;
                  if(i-1>=0&&avgDR[i-1][j]>gdtmax)
                  {
                      q=j;
                      p=i-1;
                  }
               }
               else if(ang>=22.5&&ang<67.5)
               {
                  p=i+1;
                  q=j-1;
                  if(avgDR[i-1][j+1]>gdtmax)
                  {
                      q=j+1;
                      p=i-1;
                  }
               }
               else if(ang>=67.5&&ang<112.5)
               {
                  p=i;
                  q=j-1;
                  if(avgDR[i][j+1]>gdtmax)
                  {
                      q=j+1;
                      p=i;
                  }
               }
               else if(ang>=112.5&&ang<157.5)
               {
                  p=i-1;
                  q=j-1;
                  if(avgDR[i+1][j+1]>gdtmax)
                  {
                      q=j+1;
                      p=i+1;
                  }
               }
               else if(ang>=157.5&&ang<181)
               {
                  p=i-1;
                  q=j;
                  if(avgDR[i+1][j]>gdtmax)
                  {
                      q=j;
                      p=i+1;
                  }
               }
               ang=direction1[i][j]-direction1[p][q];
               if(ang<0)ang=-ang;
               if(ang>90.0)ang=180.0-ang;
               dp=colorprewittgrad[i][j]*colorprewittgrad[p][q]*cos((M_PI*ang)/180.0);
               dp=dp/(360.0*360.0);
               realdotproduct[i][j]=dp;
               dotproduct[i][j]=(unsigned short)round((dp*360.0));
            }
        }
    }

    colorcode1(dotproduct,0,ui->lblimage_1);
}

void MainWindow::on_revGeodesic_clicked()
{
     int i=347,j=447,i1,j1,count=0;
     int p,q;
     double mindis=DR[i][j];
     slope1[i][j]=255;
     qDebug()<<"x="<<i<<","<<"y="<<j<<","<<"distance="<<DR[i][j];
     i1=i;
     j1=j;
     while(count<100)
     {
        double maxdif=-1000.0,angdif,minangdif=1000.0;

        for(q=j-1;q<=j+1;q++)
        {
            for(p=i-1;p<=i+1;p++)
            {
              if(p==i&&q==j)continue;
              //qDebug()<<DR[p][q];
              double dif=DR[i][j]-DR[p][q];
              if(dif>maxdif&&DR[p][q]<=mindis)
              {
                  //qDebug()<<"neighbor encountered";
                  mindis=DR[p][q];
                  maxdif=dif;
                  angdif=direction1[i][j]-direction1[p][q];
                  if(angdif<0)angdif=-angdif;
                  if(angdif>90.0)angdif=180-angdif;
                  if(angdif<minangdif)
                  {
                      minangdif=angdif;
                      i1=p;
                      j1=q;
                      //qDebug()<<"parent found"<<i1<<j1;
                  }
              }
            }
            //qDebug()<<"\n";
        }
        //qDebug()<<"parent found"<<i1<<j1;
        i=i1;
        j=j1;
        slope1[i][j]=255;
        qDebug()<<"x="<<i<<","<<"y="<<j<<","<<"distance="<<DR[i][j];
        count++;
     }
     qDebug()<<"count value="<<count;
     draw_image1(prewitGrad,ui->lblimage_1);

}

void MainWindow::on_scaleMap_clicked()
{

    double maxscale=0;

    for(int j=0;j<r;j++)
    {
        for(int i=0;i<c;i++)
        {
            if(scaleMap[i][j]>maxscale)maxscale=scaleMap[i][j];
        }
    }

    for(int j=0;j<r;j++)
    {
        for(int i=0;i<c;i++)
        {
            scaleMap2[i][j]=(unsigned short)round(scaleMap[i][j]*360.0/maxscale);
            scaleMap2[i][j]=360-scaleMap2[i][j];
            if(scaleMap2[i][j]<=0)scaleMap2[i][j]=1;
        }
    }

    qDebug()<<"Maximum scale of the object======>"<<maxscale;
    colorcode1(scaleMap2,0,ui->lblimage_1);

}

void MainWindow::on_SDTR_clicked()
{
    int i,j,flag1=0,p,q,iter=0;
    double cost,temp,up,uq,u,maxdt=0;
    for(j=0;j<r1;j++)
    {
        for(i=0;i<c1;i++)
        {
            if(a[i][j])sdtr[i][j]=10000.0;
            else sdtr[i][j]=0;
        }
    }

    qDebug()<<"Before entering distane transform loop";

    do
    {
        flag1=0;
        for(j=0;j<r1;j++)//Forward Pass
        {
            for(i=0;i<c1;i++)
            {

                if(a[i][j])
                {
                    up=scaleMap[i][j];
                    for(int n=0;n<4;n++)
                    {
                        p=i+npp[n][0];
                        q=j+npp[n][1];
                        if(p==i&&q==j)continue;
                        if(p>=0&&p<c1&&q>=0&&q<r1)
                        {
                            uq=scaleMap[p][q];
                            if(up>uq)u=up;
                            else u=uq;
                            //cost=(0.5*(realNDR[i][j]+realNDR[p][q]));
                            cost=neighbor[n]/u;
                            temp=sdtr[p][q]+cost;
                            if(temp<sdtr[i][j])
                            {
                                sdtr[i][j]=temp;
                                flag1++;
                            }
                        }
                    }

                }
            }
        }


       // qDebug()<<"Before entering backward pass...........";

        for(j=r1-1;j>=0;j--)//Backward Pass
        {
            for(i=c1-1;i>=0;i--)
            {
                 if(a[i][j])
                 {
                     up=scaleMap[i][j];
                     for(int n=5;n<9;n++)
                     {
                         p=i+npp[n][0];
                         q=j+npp[n][1];
                         if(p==i&&q==j)continue;
                         if(p>=0&&p<c1&&q>=0&&q<r1)
                         {
                             uq=scaleMap[p][q];
                             if(up>uq)u=up;
                             else u=uq;
                            // cost=(0.5*(realNDR[i][j]+realNDR[p][q]));
                             cost=neighbor[n]/u;
                             temp=sdtr[p][q]+cost;
                             if(temp<sdtr[i][j])
                             {
                                 sdtr[i][j]=temp;
                                 flag1++;
                             }
                         }
                     }
                 }
            }
        }

        iter++;
    }while(flag1);

    qDebug()<<"No of iteration in computing sndt"<<iter;

    for(j=0;j<r;j++)
    {
        for(i=0;i<c;i++)
        {
          if(sdtr[i][j]>maxdt)maxdt=sdtr[i][j];
          if(sdtr[i][j]>1.0)sdtr[i][j]=1.0;
        }
    }

    qDebug()<<"Maxdt scale normalized DT="<<maxdt;
    int num[361];

    for(i=0;i<361;i++)
    {
        num[i]=0;
    }
    for(j=0;j<r;j++)
    {
        for(i=0;i<c;i++)
        {
           sdtr1[i][j]=(unsigned short)round(sdtr[i][j]*255.0);
           colorsdtr[i][j]=(unsigned short)round(sdtr[i][j]*360.0);
           if(colorsdtr[i][j]>360)colorsdtr[i][j]=360;
           num[colorsdtr[i][j]]=1;
        }
    }


    draw_image1(sdtr1,ui->lblimage_1);
    colorcode1(colorsdtr,0,ui->lblimage_1);

    FILE *fp;
    fp=fopen("sigmoid.csv","wb");

        for(int i=0;i<361;i++)
        {
            if(num[i])
            fprintf(fp,"%d\n",i);
        }

    fclose(fp);

}

void geodesic1(int i,int j)
{

    int p,q,x,y,index=0,c,f=0,indexs=0;
    double ang,dotproduct,dth=0.41;
    p=i;
    q=j;
    while(p>=0&&p<c1&&q>=0&&q<r1&&
          avgDR[p][q]>gdtmax)
    {
            visited[p][q]=1;
            x=p;
            y=q;
            slope1[p][q]=255;
            ang=direction1[p][q];
            gdtmax=avgDR[p][q];
            if(ang==1000)
            {
                scaleMap[i][j]=avgDR[p][q];
                scaleMap1[i][j]=(unsigned short)round(avgDR[p][q]);
                return;
            }
            path[index].x=p;
            path[index].y=q;
            path[index].colorgrad=colorprewittgrad[p][q];
            path[index].direction=ang;
            index++;
        if(ang==90.0)
        {
            p=x;
            q=y+1;
            if(avgDR[x][y-1]>gdtmax)
            {
                p=x;
                q=y-1;
            }
        }

        else if(ang==0.0||ang==180.0)
        {
            q=y;
            p=x+1;
            if(avgDR[x-1][y]>gdtmax)
            {
                q=y;
                p=x-1;
            }
        }
        else if(ang>=0&&ang<22.5)
        {
           p=x+1;
           q=y;
           if(avgDR[x-1][y]>gdtmax)
           {
               q=y;
               p=x-1;
           }
        }
        else if(ang>=22.5&&ang<67.5)
        {
           p=x+1;
           q=y-1;
           if(avgDR[x-1][y+1]>gdtmax)
           {
               q=y+1;
               p=x-1;
           }
        }
        else if(ang>=67.5&&ang<112.5)
        {
           p=x;
           q=y-1;
           if(avgDR[x][y+1]>gdtmax)
           {
               q=y+1;
               p=x;
           }
        }
        else if(ang>=112.5&&ang<157.5)
        {
           p=x-1;
           q=y-1;
           if(avgDR[x+1][y+1]>gdtmax)
           {
               q=y+1;
               p=x+1;
           }
        }
        else if(ang>=157.5&&ang<181)
        {
           p=x-1;
           q=y;
           if(avgDR[x+1][y]>gdtmax)
           {
               q=y;
               p=x+1;
           }
        }
    }
    c=0;
    ang=path[c].direction-path[c+1].direction;
    if(ang<0)ang=-ang;
    if(ang>90.0)ang=180.0-ang;
    dotproduct=path[c].colorgrad*path[c+1].colorgrad*cos((M_PI*ang)/180.0);
    dotproduct=dotproduct/(360.0*360.0);
    path[c].dotp=dotproduct;
    if(dotproduct>dth)
    {
        for(c=1;c<index-1;c++)
        {
                ang=path[c].direction-path[c+1].direction;
                if(ang<0)ang=-ang;
                if(ang>90.0)ang=180.0-ang;
                dotproduct=path[c].colorgrad*path[c+1].colorgrad*cos((M_PI*ang)/180.0);
                dotproduct=dotproduct/(360.0*360.0);
                path[c].dotp=dotproduct;
                if(dotproduct>dth)f=0;
                if(dotproduct<=dth&&!f)
                {
                    indexs=c;
                    f=1;
                }
        }
    }
    else
    {
        f=1;
        for(c=1;c<index-1;c++)
        {
                ang=path[c].direction-path[c+1].direction;
                if(ang<0)ang=-ang;
                if(ang>90.0)ang=180.0-ang;
                dotproduct=path[c].colorgrad*path[c+1].colorgrad*cos((M_PI*ang)/180.0);
                dotproduct=dotproduct/(360.0*360.0);
                path[c].dotp=dotproduct;
                if(dotproduct>dth)f=0;
                if(dotproduct<=dth&&!f)
                {
                    indexs=c;
                    f=1;
                    //break;
                }
        }
    }

    if(f==1)
    {
        //qDebug()<<"ScaleX="<<path[indexs].x<<","<<"ScaleY="<<path[indexs].y;
        gdtmax=avgDR[path[indexs].x][path[indexs].y];
    }
    scaleMap[i][j]=gdtmax;
    scaleMap1[i][j]=(unsigned short)round(scaleMap[i][j]);


    FILE *fp;
    fp=fopen("pathAnalysis.csv","wb");
    for(c=0;c<=index-1;c++)
    {
        int x0=path[c].x;
        int y0=path[c].y;
        fprintf(fp,"%d,%d,%f,%d,%f,%f,%f,%f",x0,y0,avgDR[x0][y0],colorprewittgrad[x0][y0],direction1[x0][y0],path[c].dotp,scaleMap[x0][y0],sdtr[x0][y0]);
        fprintf(fp,"%c",'\n');
        //qDebug()<<"X="<<x0<<","<<"Y="<<y0<<","<<" EDT value"<<avgDR[x0][y0]<<" Direction="<<direction1[x0][y0]<<" Dot product="<<realdotproduct[x0][y0]<<" Object scale="<<scaleMap[x0][y0]<<" SNDT value"<<sdtr[x0][y0];
    }

    fclose(fp);
}

void MainWindow::on_drawPerpendicular_clicked()
{
   int count=0,i,j,n,d;

   for(j=0;j<r;j++)
   {
       if(count>5)break;
       for(i=0;i<c;i++)
       {
           if(boundary[i][j]==10)count++;
           if(count>5)
           {
               //if(i==279&&j==420)
                   //qDebug()<<"Inside 90 degree Gridline"<<i<<j<<"Direction angle="<<direction1[i][j];
               int p,q,p1,q1;
               double x,y,inc,m,ang;
                   x=0;
                   y=0;
                   /*if(direction1[i][j]==90||direction1[i][j]==270)
                   {
                       if(i==279&&j==420)
                           qDebug()<<"Inside 90 degree Gridline"<<i<<j;
                       p=i;
                       q=j+y;
                       q1=j-y;
                       while((q>0&&q<r1&&DR[p][q]>0)||(q1>0&&q1<r1&&DR[p][q1]>0))
                       {
                           q=j+y;
                           q1=j-y;
                           if(q>0&&q<r1&&DR[p][q]>0.0)
                           {
                                   slope1[p][q]=255;
                                   if(DR[p][q])gdtmax=DR[p][q];
                           }
                           if(q1>0&&q1<r1&&DR[p][q1]>0.0)
                           {
                                   slope1[p][q1]=255;
                                   if(DR[p][q1])gdtmax=DR[p][q1];
                           }
                           y++;
                      }

                      return;
                   }*/
                   n=xly-yuy;
                   d=xlx-yux;
                   if(d==0)ang=0;
                   m=tan((M_PI*direction1[i][j])/180.0);

                   //qDebug()<<"Slope at "<<"theta="<<direction1[i][j]<<"is"<<m;
                   if(ang==0)
                   {
                       if(i==279&&j==420)
                       qDebug()<<"Inside slope 0 Gridline"<<i<<j;
                       p=i+x;
                       q=y;
                       p1=i-x;
                       while((p>0&&p<c1&&DR[p][q]>0)||(p1>0&&p1<c1&&DR[p1][q]>0))
                       {
                           p=i+x;
                           p1=i-x;
                           if(p>0&&p<c1&&DR[p][q]>0.0)
                           {
                               slope1[p][q]=255;
                               if(DR[p][q]>gdtmax)gdtmax=DR[p][q];
                           }
                           if(p1>0&&p1<c1&&DR[p1][q]>0.0)
                           {
                               slope1[p1][q]=255;
                               if(DR[p1][q]>gdtmax)gdtmax=DR[p1][q];
                           }
                           x++;
                       }
                       return;
                   }


                   inc=1/m;
                   if(i==279&&j==420)
                   qDebug()<<"Inside Gridline"<<i<<j<<"angle="<<direction1[i][j]<<"slope="<<m<<"1/m="<<inc;
                   inc=inc/10.0;
                   //qDebug()<<"increment value="<<inc;
                   p=i+x;
                   q=j-y;
                   p1=i-x;
                   q1=j-y;
                   while((p>0&&q>0&&p<c1&&q<r1&&DR[p][q]>0.0)||(p1>0&&p1<c1&&q1>0&&q1<r1&&DR[p1][q1]>0.0))
                    {
                        y=m*x;
                        p=i+(int)round(x);
                        q=j-(int)round(y);
                        p1=i-(int)x;
                        q1=j+(int)round(y);
                        if(p>0&&p<c1&&q>0&&q<r1&&DR[p][q]>0.0)
                        {
                           slope1[p][q]=255;
                           if(DR[p][q]>gdtmax)gdtmax=DR[p][q];
                        }
                        if(p1>0&&p1<c1&&q1>0&&q1<r1&&DR[p1][q1]>0.0)
                        {
                           slope1[p1][q1]=255;
                           if(DR[p1][q1]>gdtmax)gdtmax=DR[p1][q1];
                        }
                        //slope1[(int)(i-x)][(int)(j-y)]=255;
                        x+=inc;
                    }
                   return;
               break;
           }
       }
   }
}

void geodesic2(int i,int j)
{

    int p,q,r,i1,j1,f=0;
    gdtmax=avgDR[i][j];
    slope1[i][j]=255;
    while(1)
    {
        f=0;
            for(q=j-1;q<=j+1;q++)
            {
                for(p=i-1;p<=i+1;p++)
                {
                  if(avgDR[p][q]>gdtmax)
                  {
                      gdtmax=avgDR[p][q];
                      f=1;
                      i1=p;j1=q;
                  }
                }
            }
        if(!f)
        {
            if(i1==318&&j==282)qDebug()<<"highest distance point reached";
            break;
        }
        slope1[i1][j1]=255;
        i=i1;
        j=j1;
    }
}

void MainWindow::on_sndtTh_valueChanged(int arg1)
{
    int i,j;
    for(j=0;j<r1;j++)
    {
        for(i=0;i<c1;i++)
        {
            sdtr2[i][j]=sdtr3[i][j];
        }
    }
    for(j=0;j<r1;j++)
    {
        for(i=0;i<c1;i++)
        {
            if(sdtr2[i][j]<arg1)sdtr2[i][j]=1000;
        }
    }
    colorcode1(sdtr2,0,ui->lblimage_1);
}

void MainWindow::on_exp_clicked()
{
    int i,j,a=ui->spinBox_a->value();
    double sig,maxsig=0.0;

    for(j=0;j<r1;j++)
    {
        for(i=0;i<c1;i++)
        {
            sig=2*(1/(1+exp(-a*(sdtr[i][j]-1))));
            sig=(sdtr[i][j]*sig)+((1-sdtr[i][j])*sdtr[i][j]);
            sdtr4[i][j]=sig;
            if(sig>maxsig)maxsig=sig;
            sdtr3[i][j]=(unsigned short)round((sdtr4[i][j]*360));
        }
    }

   /* for(j=0;j<r1;j++)
    {
        for(i=0;i<c1;i++)
        {
               sdtr3[i][j]=(unsigned short)round((sdtr4[i][j]/maxsig)*360);
        }
    }*/

    qDebug()<<"maxsig="<<maxsig;

    /*for(j=0;j<r1;j++)
    {
        for(i=0;i<c1;i++)
        {
            if(colorEDT[i][j])
            {
            sdtr3[i][j]=sdtr3[i][j]+(360-maxsig);
            //if(sdtr3[i][j]>maxsig)maxsig=sdtr3[i][j];
            }
        }
    }*/

    colorcode1(sdtr3,0,ui->lblimage_1);

  /* double sig=1.0/(1+exp(-0.038*160));
   qDebug()<<"sig of 180="<<sig;
   qDebug()<<"sig of 180*360="<<sig*360.0;*/
}

void MainWindow::on_sqr_clicked()
{
    int i,j,max=0,min=1000;
    double sig,maxsig=0.0,minsig=1000.0,mi,mj;

    for(j=0;j<r1;j++)
    {
        for(i=0;i<c1;i++)
        {
            if(DR[i][j]>0.0)
            {
                //sig=sdtr[i][j]/sqrt(1+(sdtr[i][j]*sdtr[i][j]*DR1[i][j]));
                sig=(sdtr[i][j]*sdtr[i][j]);
                /*if(DR1[i][j]>0.0)
                {
                    sig=sig/DR1[i][j];
                }*/
                sdtr4[i][j]=sig;
                if(sig>maxsig)
                {
                    maxsig=sig;
                    mi=i;mj=j;
                }

                if(sig<minsig&&sig>0.0)
                {
                    minsig=sig;
                    //mi=i;mj=j;
                }
            }
        }
    }

    qDebug()<<"maxsig="<<maxsig<<"max sig coordinate-x"<<mi<<"max sig coordinate-y"<<mj;
    qDebug()<<"minsig="<<minsig;
    for(j=0;j<r1;j++)
    {
        for(i=0;i<c1;i++)
        {
           if(colorsdtr[i][j])
            {
                sdtr4[i][j]=sdtr4[i][j]/maxsig;
                sdtr3[i][j]=(unsigned short)round((sdtr4[i][j]*360));
                if(sdtr3[i][j]>max)max=sdtr3[i][j];
                if(sdtr3[i][j]<min&&sdtr3[i][j])min=sdtr3[i][j];
            }

            //else sdtr3[i][j]=colorsdtr[i][j];
        }
    }

    qDebug()<<"maximum sdtr value"<<max;
    qDebug()<<"minimum sdtr value"<<min;
    for(j=0;j<r1;j++)
    {
        for(i=0;i<c1;i++)
        {
            if(colorsdtr[i][j])
            {
                if(sdtr3[i][j]==0)sdtr3[i][j]=min;
            }
        }
    }

    /*int num1[361];

    for(i=0;i<361;i++)
    {
        num1[i]=0;
    }
    for(j=0;j<r;j++)
    {
        for(i=0;i<c;i++)
        {
           num1[sdtr3[i][j]]=1;
        }
    }

    FILE *fp;
    fp=fopen("sigmoid_sndt.csv","wb");

        for(int i=0;i<361;i++)
        {
            if(num1[i])
            fprintf(fp,"%d\n",i);
        }

    fclose(fp);*/

    colorcode1(sdtr3,0,ui->lblimage_1);
}

void MainWindow::on_spinBox_a_valueChanged(int arg1)
{
    on_exp_clicked();
}

void MainWindow::on_pushButton_clicked()
{
    QString savefilepath =  QFileDialog::getSaveFileName(this, "Save as", "Choose a filename", "PNG(*.png);; TIFF(*.tiff *.tif);; JPEG(*.jpg *.jpeg)");
    ui->lblimage_1->grab().save(savefilepath);
}


void MainWindow::on_pushButton_2_clicked()
{
  int i,j;
  for(j=0;j<r;j++)
  {
      for(i=0;i<c;i++)
      {
         if(colorsdtr[i][j]>=357)a[i][j]=1000;
      }
  }
  draw_image1(a,ui->lblimage_1);
}


void MainWindow::on_pushButton_3_clicked()
{
    QString savefilepath =  QFileDialog::getSaveFileName(this, "Save as", "Choose a filename", "PNG(*.png);; TIFF(*.tiff *.tif);; JPEG(*.jpg *.jpeg)");
    ui->lblimage_1->grab().save(savefilepath);
}

