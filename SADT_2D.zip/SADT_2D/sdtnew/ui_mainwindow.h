/********************************************************************************
** Form generated from reading UI file 'mainwindow.ui'
**
** Created by: Qt User Interface Compiler version 5.15.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MAINWINDOW_H
#define UI_MAINWINDOW_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QCheckBox>
#include <QtWidgets/QDoubleSpinBox>
#include <QtWidgets/QFrame>
#include <QtWidgets/QLabel>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QSpinBox>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_MainWindow
{
public:
    QWidget *centralWidget;
    QLabel *label_15;
    QLabel *Xdim_2;
    QLabel *ydimname_2;
    QLabel *Ydim_2;
    QCheckBox *colorEDT;
    QPushButton *loadimg;
    QLabel *lblimage_1;
    QPushButton *EDTOLD;
    QCheckBox *blackBG;
    QSpinBox *AvgWindow;
    QLabel *label_7;
    QPushButton *gradient;
    QPushButton *gradDirection;
    QCheckBox *colorGrad;
    QPushButton *drawGradLine;
    QPushButton *NEDT;
    QFrame *line;
    QPushButton *CCL;
    QPushButton *EDTN;
    QPushButton *boundary;
    QSpinBox *nedtth;
    QLabel *label_2;
    QPushButton *writeneighbor;
    QDoubleSpinBox *realndr;
    QPushButton *dotproduct;
    QPushButton *revGeodesic;
    QPushButton *scaleMap;
    QPushButton *SDTR;
    QPushButton *drawPerpendicular;
    QSpinBox *sndtTh;
    QPushButton *exp;
    QPushButton *sqr;
    QSpinBox *spinBox_a;
    QPushButton *pushButton;
    QPushButton *pushButton_2;
    QPushButton *pushButton_3;
    QStatusBar *statusBar;

    void setupUi(QMainWindow *MainWindow)
    {
        if (MainWindow->objectName().isEmpty())
            MainWindow->setObjectName(QString::fromUtf8("MainWindow"));
        MainWindow->resize(1379, 1050);
        QPalette palette;
        QBrush brush(QColor(0, 0, 0, 255));
        brush.setStyle(Qt::SolidPattern);
        palette.setBrush(QPalette::Active, QPalette::WindowText, brush);
        QBrush brush1(QColor(255, 255, 255, 255));
        brush1.setStyle(Qt::SolidPattern);
        palette.setBrush(QPalette::Active, QPalette::Button, brush1);
        palette.setBrush(QPalette::Active, QPalette::Light, brush1);
        palette.setBrush(QPalette::Active, QPalette::Midlight, brush1);
        QBrush brush2(QColor(127, 127, 127, 255));
        brush2.setStyle(Qt::SolidPattern);
        palette.setBrush(QPalette::Active, QPalette::Dark, brush2);
        QBrush brush3(QColor(170, 170, 170, 255));
        brush3.setStyle(Qt::SolidPattern);
        palette.setBrush(QPalette::Active, QPalette::Mid, brush3);
        palette.setBrush(QPalette::Active, QPalette::Text, brush);
        palette.setBrush(QPalette::Active, QPalette::BrightText, brush1);
        palette.setBrush(QPalette::Active, QPalette::ButtonText, brush);
        palette.setBrush(QPalette::Active, QPalette::Base, brush1);
        palette.setBrush(QPalette::Active, QPalette::Window, brush1);
        palette.setBrush(QPalette::Active, QPalette::Shadow, brush);
        palette.setBrush(QPalette::Active, QPalette::AlternateBase, brush1);
        QBrush brush4(QColor(255, 255, 220, 255));
        brush4.setStyle(Qt::SolidPattern);
        palette.setBrush(QPalette::Active, QPalette::ToolTipBase, brush4);
        palette.setBrush(QPalette::Active, QPalette::ToolTipText, brush);
        palette.setBrush(QPalette::Inactive, QPalette::WindowText, brush);
        QBrush brush5(QColor(240, 240, 240, 255));
        brush5.setStyle(Qt::SolidPattern);
        palette.setBrush(QPalette::Inactive, QPalette::Button, brush5);
        palette.setBrush(QPalette::Inactive, QPalette::Light, brush1);
        QBrush brush6(QColor(227, 227, 227, 255));
        brush6.setStyle(Qt::SolidPattern);
        palette.setBrush(QPalette::Inactive, QPalette::Midlight, brush6);
        QBrush brush7(QColor(160, 160, 160, 255));
        brush7.setStyle(Qt::SolidPattern);
        palette.setBrush(QPalette::Inactive, QPalette::Dark, brush7);
        palette.setBrush(QPalette::Inactive, QPalette::Mid, brush7);
        palette.setBrush(QPalette::Inactive, QPalette::Text, brush);
        palette.setBrush(QPalette::Inactive, QPalette::BrightText, brush1);
        palette.setBrush(QPalette::Inactive, QPalette::ButtonText, brush);
        palette.setBrush(QPalette::Inactive, QPalette::Base, brush1);
        palette.setBrush(QPalette::Inactive, QPalette::Window, brush5);
        QBrush brush8(QColor(105, 105, 105, 255));
        brush8.setStyle(Qt::SolidPattern);
        palette.setBrush(QPalette::Inactive, QPalette::Shadow, brush8);
        QBrush brush9(QColor(245, 245, 245, 255));
        brush9.setStyle(Qt::SolidPattern);
        palette.setBrush(QPalette::Inactive, QPalette::AlternateBase, brush9);
        palette.setBrush(QPalette::Inactive, QPalette::ToolTipBase, brush4);
        palette.setBrush(QPalette::Inactive, QPalette::ToolTipText, brush);
        palette.setBrush(QPalette::Disabled, QPalette::WindowText, brush2);
        palette.setBrush(QPalette::Disabled, QPalette::Button, brush1);
        palette.setBrush(QPalette::Disabled, QPalette::Light, brush1);
        palette.setBrush(QPalette::Disabled, QPalette::Midlight, brush1);
        palette.setBrush(QPalette::Disabled, QPalette::Dark, brush2);
        palette.setBrush(QPalette::Disabled, QPalette::Mid, brush3);
        palette.setBrush(QPalette::Disabled, QPalette::Text, brush2);
        palette.setBrush(QPalette::Disabled, QPalette::BrightText, brush1);
        palette.setBrush(QPalette::Disabled, QPalette::ButtonText, brush2);
        palette.setBrush(QPalette::Disabled, QPalette::Base, brush1);
        palette.setBrush(QPalette::Disabled, QPalette::Window, brush1);
        palette.setBrush(QPalette::Disabled, QPalette::Shadow, brush);
        palette.setBrush(QPalette::Disabled, QPalette::AlternateBase, brush9);
        palette.setBrush(QPalette::Disabled, QPalette::ToolTipBase, brush4);
        palette.setBrush(QPalette::Disabled, QPalette::ToolTipText, brush);
        MainWindow->setPalette(palette);
        MainWindow->setAutoFillBackground(true);
        centralWidget = new QWidget(MainWindow);
        centralWidget->setObjectName(QString::fromUtf8("centralWidget"));
        label_15 = new QLabel(centralWidget);
        label_15->setObjectName(QString::fromUtf8("label_15"));
        label_15->setGeometry(QRect(1260, 50, 47, 31));
        QFont font;
        font.setPointSize(10);
        font.setBold(true);
        label_15->setFont(font);
        Xdim_2 = new QLabel(centralWidget);
        Xdim_2->setObjectName(QString::fromUtf8("Xdim_2"));
        Xdim_2->setGeometry(QRect(1310, 50, 71, 31));
        Xdim_2->setFrameShape(QFrame::Box);
        ydimname_2 = new QLabel(centralWidget);
        ydimname_2->setObjectName(QString::fromUtf8("ydimname_2"));
        ydimname_2->setGeometry(QRect(1260, 90, 51, 31));
        ydimname_2->setFont(font);
        Ydim_2 = new QLabel(centralWidget);
        Ydim_2->setObjectName(QString::fromUtf8("Ydim_2"));
        Ydim_2->setGeometry(QRect(1310, 90, 71, 31));
        Ydim_2->setFrameShape(QFrame::Box);
        colorEDT = new QCheckBox(centralWidget);
        colorEDT->setObjectName(QString::fromUtf8("colorEDT"));
        colorEDT->setGeometry(QRect(1270, 260, 111, 17));
        QFont font1;
        font1.setPointSize(8);
        font1.setBold(false);
        colorEDT->setFont(font1);
        loadimg = new QPushButton(centralWidget);
        loadimg->setObjectName(QString::fromUtf8("loadimg"));
        loadimg->setGeometry(QRect(1260, 10, 121, 28));
        loadimg->setFont(font1);
        lblimage_1 = new QLabel(centralWidget);
        lblimage_1->setObjectName(QString::fromUtf8("lblimage_1"));
        lblimage_1->setGeometry(QRect(10, 20, 500, 500));
        QSizePolicy sizePolicy(QSizePolicy::Minimum, QSizePolicy::Minimum);
        sizePolicy.setHorizontalStretch(0);
        sizePolicy.setVerticalStretch(0);
        sizePolicy.setHeightForWidth(lblimage_1->sizePolicy().hasHeightForWidth());
        lblimage_1->setSizePolicy(sizePolicy);
        lblimage_1->setCursor(QCursor(Qt::ArrowCursor));
        lblimage_1->setMouseTracking(true);
        lblimage_1->setAutoFillBackground(false);
        lblimage_1->setFrameShape(QFrame::NoFrame);
        lblimage_1->setLineWidth(1);
        lblimage_1->setScaledContents(true);
        lblimage_1->setAlignment(Qt::AlignLeading|Qt::AlignLeft|Qt::AlignTop);
        EDTOLD = new QPushButton(centralWidget);
        EDTOLD->setObjectName(QString::fromUtf8("EDTOLD"));
        EDTOLD->setGeometry(QRect(1270, 220, 91, 28));
        EDTOLD->setFont(font1);
        blackBG = new QCheckBox(centralWidget);
        blackBG->setObjectName(QString::fromUtf8("blackBG"));
        blackBG->setGeometry(QRect(1260, 330, 121, 20));
        blackBG->setFont(font);
        AvgWindow = new QSpinBox(centralWidget);
        AvgWindow->setObjectName(QString::fromUtf8("AvgWindow"));
        AvgWindow->setGeometry(QRect(1170, 620, 42, 22));
        label_7 = new QLabel(centralWidget);
        label_7->setObjectName(QString::fromUtf8("label_7"));
        label_7->setGeometry(QRect(1170, 590, 81, 20));
        label_7->setFont(font1);
        gradient = new QPushButton(centralWidget);
        gradient->setObjectName(QString::fromUtf8("gradient"));
        gradient->setGeometry(QRect(1260, 360, 121, 41));
        gradient->setFont(font);
        gradDirection = new QPushButton(centralWidget);
        gradDirection->setObjectName(QString::fromUtf8("gradDirection"));
        gradDirection->setGeometry(QRect(1260, 410, 121, 41));
        gradDirection->setFont(font);
        colorGrad = new QCheckBox(centralWidget);
        colorGrad->setObjectName(QString::fromUtf8("colorGrad"));
        colorGrad->setGeometry(QRect(1260, 470, 121, 20));
        colorGrad->setFont(font);
        drawGradLine = new QPushButton(centralWidget);
        drawGradLine->setObjectName(QString::fromUtf8("drawGradLine"));
        drawGradLine->setGeometry(QRect(1260, 500, 121, 28));
        drawGradLine->setFont(font1);
        NEDT = new QPushButton(centralWidget);
        NEDT->setObjectName(QString::fromUtf8("NEDT"));
        NEDT->setGeometry(QRect(1260, 530, 121, 28));
        NEDT->setFont(font1);
        line = new QFrame(centralWidget);
        line->setObjectName(QString::fromUtf8("line"));
        line->setGeometry(QRect(1140, -30, 31, 1011));
        line->setFrameShape(QFrame::VLine);
        line->setFrameShadow(QFrame::Sunken);
        CCL = new QPushButton(centralWidget);
        CCL->setObjectName(QString::fromUtf8("CCL"));
        CCL->setGeometry(QRect(1270, 130, 93, 28));
        EDTN = new QPushButton(centralWidget);
        EDTN->setObjectName(QString::fromUtf8("EDTN"));
        EDTN->setGeometry(QRect(1270, 190, 93, 28));
        boundary = new QPushButton(centralWidget);
        boundary->setObjectName(QString::fromUtf8("boundary"));
        boundary->setGeometry(QRect(1270, 160, 93, 28));
        nedtth = new QSpinBox(centralWidget);
        nedtth->setObjectName(QString::fromUtf8("nedtth"));
        nedtth->setGeometry(QRect(1300, 290, 42, 22));
        nedtth->setMaximum(360);
        label_2 = new QLabel(centralWidget);
        label_2->setObjectName(QString::fromUtf8("label_2"));
        label_2->setGeometry(QRect(1250, 290, 41, 16));
        writeneighbor = new QPushButton(centralWidget);
        writeneighbor->setObjectName(QString::fromUtf8("writeneighbor"));
        writeneighbor->setGeometry(QRect(1150, 750, 111, 41));
        realndr = new QDoubleSpinBox(centralWidget);
        realndr->setObjectName(QString::fromUtf8("realndr"));
        realndr->setGeometry(QRect(1180, 800, 62, 22));
        realndr->setValue(2.000000000000000);
        dotproduct = new QPushButton(centralWidget);
        dotproduct->setObjectName(QString::fromUtf8("dotproduct"));
        dotproduct->setGeometry(QRect(1140, 650, 121, 41));
        dotproduct->setFont(font);
        revGeodesic = new QPushButton(centralWidget);
        revGeodesic->setObjectName(QString::fromUtf8("revGeodesic"));
        revGeodesic->setGeometry(QRect(1122, 700, 161, 41));
        revGeodesic->setFont(font);
        scaleMap = new QPushButton(centralWidget);
        scaleMap->setObjectName(QString::fromUtf8("scaleMap"));
        scaleMap->setGeometry(QRect(1140, 830, 121, 41));
        QFont font2;
        font2.setPointSize(9);
        font2.setBold(true);
        scaleMap->setFont(font2);
        SDTR = new QPushButton(centralWidget);
        SDTR->setObjectName(QString::fromUtf8("SDTR"));
        SDTR->setGeometry(QRect(1150, 880, 93, 28));
        SDTR->setFont(font);
        drawPerpendicular = new QPushButton(centralWidget);
        drawPerpendicular->setObjectName(QString::fromUtf8("drawPerpendicular"));
        drawPerpendicular->setGeometry(QRect(1130, 910, 151, 41));
        QFont font3;
        font3.setBold(true);
        drawPerpendicular->setFont(font3);
        sndtTh = new QSpinBox(centralWidget);
        sndtTh->setObjectName(QString::fromUtf8("sndtTh"));
        sndtTh->setGeometry(QRect(1170, 960, 42, 22));
        sndtTh->setMaximum(360);
        exp = new QPushButton(centralWidget);
        exp->setObjectName(QString::fromUtf8("exp"));
        exp->setGeometry(QRect(1190, 560, 93, 28));
        sqr = new QPushButton(centralWidget);
        sqr->setObjectName(QString::fromUtf8("sqr"));
        sqr->setGeometry(QRect(1290, 560, 93, 28));
        spinBox_a = new QSpinBox(centralWidget);
        spinBox_a->setObjectName(QString::fromUtf8("spinBox_a"));
        spinBox_a->setGeometry(QRect(1220, 620, 42, 22));
        spinBox_a->setMaximum(1000);
        spinBox_a->setValue(1);
        pushButton = new QPushButton(centralWidget);
        pushButton->setObjectName(QString::fromUtf8("pushButton"));
        pushButton->setGeometry(QRect(1270, 830, 93, 29));
        pushButton_2 = new QPushButton(centralWidget);
        pushButton_2->setObjectName(QString::fromUtf8("pushButton_2"));
        pushButton_2->setGeometry(QRect(1160, 40, 93, 29));
        pushButton_3 = new QPushButton(centralWidget);
        pushButton_3->setObjectName(QString::fromUtf8("pushButton_3"));
        pushButton_3->setGeometry(QRect(1270, 610, 93, 29));
        MainWindow->setCentralWidget(centralWidget);
        statusBar = new QStatusBar(MainWindow);
        statusBar->setObjectName(QString::fromUtf8("statusBar"));
        MainWindow->setStatusBar(statusBar);

        retranslateUi(MainWindow);

        QMetaObject::connectSlotsByName(MainWindow);
    } // setupUi

    void retranslateUi(QMainWindow *MainWindow)
    {
        MainWindow->setWindowTitle(QCoreApplication::translate("MainWindow", "MainWindow", nullptr));
        label_15->setText(QCoreApplication::translate("MainWindow", "Xdim", nullptr));
        Xdim_2->setText(QString());
        ydimname_2->setText(QCoreApplication::translate("MainWindow", "Ydim", nullptr));
        Ydim_2->setText(QString());
        colorEDT->setText(QCoreApplication::translate("MainWindow", "Color EDT", nullptr));
        loadimg->setText(QCoreApplication::translate("MainWindow", "Load Image", nullptr));
        lblimage_1->setText(QString());
        EDTOLD->setText(QCoreApplication::translate("MainWindow", "EuclideanDT ", nullptr));
        blackBG->setText(QCoreApplication::translate("MainWindow", "Black Bg", nullptr));
        label_7->setText(QCoreApplication::translate("MainWindow", "Avg Window", nullptr));
        gradient->setText(QCoreApplication::translate("MainWindow", "Gradient", nullptr));
        gradDirection->setText(QCoreApplication::translate("MainWindow", "Direction", nullptr));
        colorGrad->setText(QCoreApplication::translate("MainWindow", "Color Grad", nullptr));
        drawGradLine->setText(QCoreApplication::translate("MainWindow", "Grad Line", nullptr));
        NEDT->setText(QCoreApplication::translate("MainWindow", "NEDT", nullptr));
        CCL->setText(QCoreApplication::translate("MainWindow", "CCL", nullptr));
        EDTN->setText(QCoreApplication::translate("MainWindow", "EDTN", nullptr));
        boundary->setText(QCoreApplication::translate("MainWindow", "Boundary", nullptr));
        label_2->setText(QCoreApplication::translate("MainWindow", "NEDT", nullptr));
        writeneighbor->setText(QCoreApplication::translate("MainWindow", "Write Neighbor", nullptr));
        dotproduct->setText(QCoreApplication::translate("MainWindow", "Dot Product", nullptr));
        revGeodesic->setText(QCoreApplication::translate("MainWindow", "Reverse Geodesic", nullptr));
        scaleMap->setText(QCoreApplication::translate("MainWindow", "Scale Map", nullptr));
        SDTR->setText(QCoreApplication::translate("MainWindow", "SDTR", nullptr));
        drawPerpendicular->setText(QCoreApplication::translate("MainWindow", "Draw perpendicular", nullptr));
        exp->setText(QCoreApplication::translate("MainWindow", "Ex", nullptr));
        sqr->setText(QCoreApplication::translate("MainWindow", "sqr", nullptr));
        pushButton->setText(QCoreApplication::translate("MainWindow", "save", nullptr));
        pushButton_2->setText(QCoreApplication::translate("MainWindow", "core", nullptr));
        pushButton_3->setText(QCoreApplication::translate("MainWindow", "save2", nullptr));
    } // retranslateUi

};

namespace Ui {
    class MainWindow: public Ui_MainWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MAINWINDOW_H
