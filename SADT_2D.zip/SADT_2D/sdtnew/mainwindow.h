#ifndef MAINWINDOW_H
#define MAINWINDOW_H
#include <QMainWindow>
#define sizex 1024
#define sizey 1024
#include<QLabel>
namespace Ui {
class MainWindow;
}

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit MainWindow(QWidget *parent = nullptr);
    ~MainWindow();

private slots:

    void on_loadimg_clicked();

    void on_colorEDT_stateChanged(int arg1);

    void on_EDTOLD_clicked();

    void on_gradient_clicked();

    void on_colorGrad_stateChanged(int arg1);

    void on_gradDirection_clicked();

    void on_drawGradLine_clicked();

    void on_NEDT_clicked();

    void on_CCL_clicked();

    void on_EDTN_clicked();

    void on_boundary_clicked();

    void on_nedtth_valueChanged(int arg1);

    void on_GT_valueChanged(int arg1);

    void on_writeneighbor_clicked();

    void on_realndr_valueChanged(double arg1);

    void on_dotproduct_clicked();

    void on_revGeodesic_clicked();

    void on_scaleMap_clicked();

    void on_SDTR_clicked();

    void on_drawPerpendicular_clicked();

    void on_sndtTh_valueChanged(int arg1);

    void on_exp_clicked();

    void on_sqr_clicked();

    void on_spinBox_a_valueChanged(int arg1);

    void on_pushButton_clicked();

    void on_pushButton_2_clicked();

    void on_pushButton_3_clicked();

protected:
      void        mouseMoveEvent( QMouseEvent * );
      void        mousePressEvent( QMouseEvent * );
      //void        wheelEvent(QWheelEvent *);
     // void        mouseReleaseEvent(QMouseEvent *);
      //void        mouseDoubleClickEvent(QMouseEvent *e);

private:
    Ui::MainWindow *ui;
    void draw_image1(unsigned short **, QLabel *);
    void draw_image2(unsigned short **);
    void allocate_memory1();
    void free_memory1();
    void compute_dt();
    void compute_subdt();
    void compute_EDT();
    void symfdt();
    void EDT_CI();
    double cal_sineval(double);
    double cal_cosineval(double);
    void colorcode1(unsigned short **,int,QLabel *);
    void anglecolorcode(unsigned short **,int,QLabel *);
    void computerealdt();
    void centreofmaxball();
    void centreofmaxball1();
};

#endif // MAINWINDOW_H
