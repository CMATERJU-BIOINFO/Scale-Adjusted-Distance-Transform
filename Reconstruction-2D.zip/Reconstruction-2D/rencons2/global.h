#ifndef GLOBAL_H
#define GLOBAL_H
#include<cmath>
#define R2 1.41
#define R3 1.73
#define MAX 100//maximum nummber of spines in an image
#define MaxSeed 1000
int isprofileloaded=0,ispreprocessed=0,zoomscale=1;

int maxInt=9999;
int start=0,totalseed=0;
unsigned short **colorsdtr,**vol,**vol1,**NNDT,**colorEDT,**colorMatrix,**slope1,**NDT,
**boundary,**core,**common,**rec,**EDT,md=0,**coreA,**coreV;

unsigned char **visited;
int npp[9][2]={
                {-1,-1},{0,-1},{1,-1},
                {-1, 0},{0,0},{1,0},
                {-1, 1},{0,1},{1,1}
               };

char neighbor[27]={   4,3,4,
                      3,0,3,
                      4,3,4
                   };

double gauss[125];
struct voxel
{
    int x,y;
};

struct color
{
   int index,red,green,blue;
};

struct color color1[360];
struct voxel **vox,path[1000000];
#endif // GLOBAL_H
