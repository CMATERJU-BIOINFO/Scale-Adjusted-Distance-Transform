#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>

namespace Ui {
class MainWindow;
}

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit MainWindow(QWidget *parent = 0);
    ~MainWindow();
    //public slots:
        void My_Main();

    protected:
          void        mouseMoveEvent( QMouseEvent * );
          void        mousePressEvent( QMouseEvent * );
          void        wheelEvent(QWheelEvent *);
          void        mouseDoubleClickEvent(QMouseEvent *e);

private:
    Ui::MainWindow *ui;
    QByteArray filename, only_filename;
    unsigned short curX;
    unsigned short curY;
    unsigned short curZ;
    unsigned short Xdim1,Xdim;
    unsigned short Ydim1,Ydim;
    unsigned short Zdim1,Zdim;
    float sp[3];
    unsigned long hist[6000];
    unsigned long hmax;
    float scale;
    float maxFDTb;
    float maxFDTv;
    unsigned short Flag;
    unsigned short GITN;
    char DataID[100];
    short offset;
    int maxFDT;
    int mouseY=0,mousefp=0,mousefn=0;
    int recX=-1, recY=-1,recL=0,recW=0;
    int ROIindex=0;
    //short int *vol;
    struct ROI
    {
        int ta,tb,tbp,recX,recY,recW,recL,sizex,sizey,sizez,segment_flag=0,analysis_flag=0,iterate=0;
    }ROI;
  struct ROI listROI[150];
  int ROIflag=0;
  typedef signed short        InputPixelType;
  typedef unsigned char        OutputPixelType;


  void draw_fullimage(unsigned short **);
  void allocate_memory();
  void readImage();
  void readCore();
  void grow();
  void reset();

  void colorcode(unsigned short **,int,int);
  void colorcode2D(unsigned short **,int,int,int);
  void anglecolorcode(unsigned short **,int);
  void GaussSmoothing_2D();
private slots:

    void on_actionLoad_Image_triggered();
    void on_spinBox_curX_valueChanged(int x);
    void on_spinBox_curY_valueChanged(int y);
    void on_spinBox_curZ_valueChanged(int z);
    void on_actionShow_Gridlines_triggered();
    void on_actionSave_triggered();
    void on_actionExit_triggered();
    void on_EDT_clicked();
    void on_actionColorize_triggered();
    void on_surface_clicked();
    void on_recons_clicked();
};

#endif // MAINWINDOW_H
