#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <QtGui>
#include <string.h>
#include "global.h"
#include<QFileDialog>
#include<QString>
#include <iostream>
#include<cmath>
#include<QScrollBar>
#include<QMessageBox>
#include<QDesktopWidget>
using namespace std;
MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    setWindowTitle("SNDT:Shape Normalized Distance Transform");
   // ui->comboBox->addItem("Type");

    ui->sliceLabel->setAlignment(Qt::AlignTop);
    ui->actionSelect_a_region->setVisible(false);
    ui->actionScale->setVisible(false);
    ui->scrollArea->horizontalScrollBar()->setDisabled(true);
    ui->scrollArea->verticalScrollBar()->setDisabled(true);
   //ui->actionSave_Seeds_2->setEnabled(false);
    ui->actionSave_ROIProfile->setEnabled(false);
    //this->setFixedSize(this->geometry().width(),this->geometry().height());
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::on_actionLoad_Image_triggered()
{
    QString temp;

    temp=QFileDialog::getOpenFileName(this,tr("Open File"), "",
                                      tr("Analyze Images (*.img)"));
    if(QString::compare(temp,QString())==0)return;
    start=1;
    QByteArray qb = temp.toLatin1();
    filename =  qb.data();
    short c1=filename.lastIndexOf("/");
    short c2=filename.lastIndexOf(".");
    only_filename=filename.mid(c1+1,c2-c1-1);
    strcpy(DataID,only_filename);
    ui->scrollArea->horizontalScrollBar()->setEnabled(true);
    ui->scrollArea->verticalScrollBar()->setEnabled(true);
    Xdim=ui->xdimvalue->text().toInt();
    Ydim=ui->ydimvalue->text().toInt();
    Zdim=ui->zdimvalue->text().toInt();
    ui->spinBox_curX->setMaximum(Xdim-1);
    ui->spinBox_curY->setMaximum(Ydim-1);
    ui->spinBox_curZ->setMaximum(Zdim-1);
    curX=Xdim/2;
    curY=Ydim/2;
    curZ=Zdim/2;
    reset();
    allocate_memory();
    readImage();
    draw_fullimage(vol);
    ui->spinBox_curX->setValue(curX);
    ui->spinBox_curY->setValue(curY);
    ui->spinBox_curZ->setValue(curZ);
}

void MainWindow::allocate_memory()
{
    rec=(unsigned short **)calloc(sizeof(unsigned short *) , Xdim);
    common=(unsigned short **)calloc(sizeof(unsigned short *) , Xdim);
    core=(unsigned short **)calloc(sizeof(unsigned short *) , Xdim);
    coreA=(unsigned short **)calloc(sizeof(unsigned short *) , Xdim);
    coreV=(unsigned short **)calloc(sizeof(unsigned short *) , Xdim);
    vol1=(unsigned short **)calloc(sizeof(unsigned short *) , Xdim);
    visited=(unsigned char **)calloc(sizeof(unsigned char *) , Xdim);
    colorsdtr=(unsigned short **)calloc(sizeof(unsigned short *) , Xdim);
    EDT=(unsigned short **)calloc(sizeof(unsigned short *) , Xdim);
    colorEDT=(unsigned short **)calloc(sizeof(unsigned short *) , Xdim);
    NDT=(unsigned short **)calloc(sizeof(unsigned short *) , Xdim);
    slope1=(unsigned short **)calloc(sizeof(unsigned short *) , Xdim);
    NNDT=(unsigned short **)calloc(sizeof(unsigned short *) , Xdim);
    boundary=(unsigned short **)calloc(sizeof(unsigned short *) , Xdim);
    vox=(struct voxel **)calloc(sizeof(struct voxel *) , Xdim);
    for (int i = 0 ;  i < Xdim; i++) {
        rec[i]=(unsigned short *)calloc(sizeof(unsigned short) , Ydim);
        common[i]=(unsigned short *)calloc(sizeof(unsigned short) , Ydim);
        vol1[i]=(unsigned short *)calloc(sizeof(unsigned short) , Ydim);
        core[i]=(unsigned short *)calloc(sizeof(unsigned short) , Ydim);
        coreA[i]=(unsigned short *)calloc(sizeof(unsigned short) , Ydim);
        coreV[i]=(unsigned short *)calloc(sizeof(unsigned short) , Ydim);
        visited[i]=(unsigned char *)calloc(sizeof(unsigned char) , Ydim);
        EDT[i]=(unsigned short *)calloc(sizeof(unsigned short) , Ydim);
        colorsdtr[i]=(unsigned short *)calloc(sizeof(unsigned short),Ydim);
        NNDT[i]=(unsigned short *)calloc(sizeof(unsigned short) , Ydim);
        colorEDT[i]=(unsigned short *)calloc(sizeof(unsigned short) , Ydim);
        NDT[i]=(unsigned short *)calloc(sizeof(unsigned short) , Ydim);
        slope1[i]=(unsigned short *)calloc(sizeof(unsigned short) , Ydim);
        boundary[i]=(unsigned short *)calloc(sizeof(unsigned short) , Ydim);
        vox[i]=(struct voxel *)calloc(sizeof(struct voxel) , Ydim);

    }

}

void MainWindow::reset()
{
  free(coreA);coreA=NULL;
  free(coreV);coreV=NULL;
  free(core);core=NULL;
  free(boundary);boundary=NULL;
  free(visited);visited=NULL;
  free(colorsdtr);colorsdtr=NULL;
  free(EDT);EDT=NULL;
  free(NNDT);NNDT=NULL;
  free(vol);vol=NULL;
  free(vol1);vol1=NULL;
  free(vox);vox=NULL;
  free(colorEDT);colorEDT=NULL;
  free(slope1);slope1=NULL;
  free(NDT);NDT=NULL;
  free(common);common=NULL;
  free(rec);rec=NULL;
}

void MainWindow::readImage()
{
   FILE *fp;
   fp=fopen(filename,"rb");
   int i,j;
   unsigned char val1;
   unsigned short val;

       for(j=0;j<Ydim;j++)
       {
           for(i=0;i<Xdim;i++)
           {
               fread(&val1,sizeof(unsigned char),1,fp);
               if(val1)val1=255;
               vol1[i][j]=(unsigned short)val1;
           }
       }


   fclose(fp);
   vol=vol1;
}

void MainWindow::on_spinBox_curX_valueChanged(int x)
{
        curX=x;
        if(ui->actionColorize->isChecked())
            colorcode(colorMatrix,0,curZ);
        else draw_fullimage(vol);
}

void MainWindow::on_spinBox_curY_valueChanged(int y)
{

        curY=y;
        if(ui->actionColorize->isChecked())
            colorcode(colorMatrix,0,curZ);
        else draw_fullimage(vol);
}

void MainWindow::on_spinBox_curZ_valueChanged(int z)
{
        curZ=z;
        if(ui->actionColorize->isChecked())
            colorcode(colorMatrix,0,curZ);
//        if(ui->actionColor_coded_direction->isChecked())
//            anglecolorcode(dir,curZ);
        else draw_fullimage(vol);
}

void MainWindow::wheelEvent(QWheelEvent *e)
{
    int t,v;
        if(e->orientation() == Qt::Vertical/*&&e->modifiers()==Qt::CTRL*/)
        {
            t= (int)(e->delta())/120;
            v=ui->spinBox_curZ->value();

            if (v>=0 && v<=Zdim-1)
            {
                if(v==0 && t<0) return;
                if(v==Zdim-1 && t>0) return;

                ui->spinBox_curZ->setValue(v+t);
            }
        }
}

void MainWindow::mouseMoveEvent(QMouseEvent *e)
{
if(e->buttons()==Qt::RightButton)
{
  if(e->pos().y()>mouseY)
  {
   mouseY=e->pos().y();
   mousefp++;
   if(mousefp>10)
   {
       mousefp=0;
       //if(zoomscale>1)
       //zoomscale=zoomscale-1;
       draw_fullimage(vol);
   }
  }
  else if(e->pos().y()<mouseY)
  {
    mouseY=e->pos().y();
    mousefn++;
    if(mousefn>10)
    {
        mousefn=0;
        //zoomscale=zoomscale+1;
        draw_fullimage(vol);
    }
  }
}

if(e->buttons()==Qt::LeftButton)
{

    if(ui->actionSelect_a_region->isChecked())
    {

        //qDebug()<<"Inside mouse movement and region checked\n";
        int qx=(e->x()-ui->scrollArea->x()+ui->scrollArea->horizontalScrollBar()->value())-ui->sliceLabel->x()-1;
        int qy=(e->y()-ui->scrollArea->y()-ui->mainToolBar->height()-ui->menuBar->height()+ui->scrollArea->verticalScrollBar()->value())-ui->sliceLabel->y()-1;
        if(qx<Xdim && qy<Ydim && qx>recX && qy>recY)
         {
            recL=abs((qy-recY));
            recW=abs((qx-recX));
         }
         if(recX!=-1&&recY!=-1&&recL&&recW)
         draw_fullimage(vol);
    }

    if(e->modifiers()==Qt::CTRL)
    {
        //qDebug()<<"intensity assigned zero";
        int qx=(e->x()-ui->scrollArea->x()+ui->scrollArea->horizontalScrollBar()->value())-ui->sliceLabel->x()-1;
        int qy=(e->y()-ui->scrollArea->y()-ui->mainToolBar->height()-ui->menuBar->height()+ui->scrollArea->verticalScrollBar()->value())-ui->sliceLabel->y()-1;
        qx=qx;//zoomscale;
        qy=qy;//zoomscale;
        if(qx<Xdim && qy<Ydim && qx>recX && qy>recY)
         {
            if(start==0)return;
         }
        //draw_image();
    }
}
}

void MainWindow::mousePressEvent(QMouseEvent *e )
{

    /*if(e->button()==Qt::RightButton)
    {
        mouseY=0;mousefp=0,mousefn=0;
    }*/
    if(start==0)return;
    QPoint pt,pt1;
    char name[200];
    int x,y;
   // pt=e->pos();
    int q;
    if(e->buttons()==Qt::RightButton)return;
    q=(e->x()-ui->scrollArea->x()+ui->scrollArea->horizontalScrollBar()->value());
    x=q-ui->sliceLabel->x()-1;

    q=(e->y()-ui->scrollArea->y()-ui->mainToolBar->height()-ui->menuBar->height()+ui->scrollArea->verticalScrollBar()->value());
    y=q-ui->sliceLabel->y()-1;

   // x=pt.x()-ui->scrollArea->x()+ui->scrollArea->horizontalScrollBar()->value();
    //y=pt.y()-ui->scrollArea->y()-ui->mainToolBar->height()+ui->scrollArea->verticalScrollBar()->value();
    x=x;//zoomscale;
    y=y;//zoomscale;



            if(Xdim==0 ||Ydim==0 ||Zdim==0) return;


            if(x>0 && y>0&&
                    x<(Xdim) &&
                    y<(Ydim))

            {
                //qDebug()<<"Value x................."<<x;
                curX=x;
                curY=y;
//                recX=curX;
//                recY=curY;
                //qDebug()<<"Value curX"<<curX;
                ui->label_12->setNum(vol[curX][curY]);
                ui->spinBox_curX->setValue(curX);//me->globalX());
                ui->spinBox_curY->setValue(curY);//me->globalX());

                if(ui->actionShow_Gridlines->isChecked()==true)
                {
                    draw_fullimage(vol);
                }
             }


}

void MainWindow::on_actionShow_Gridlines_triggered()
{
    draw_fullimage(vol);
}

void MainWindow::on_actionSave_triggered()
{
    QByteArray onlyfilename1=only_filename;
    unsigned short value;
    unsigned char value1;
    QByteArray outputfilename;
    QString savefilepath=QFileDialog::getSaveFileName(this,tr("Save as"),onlyfilename1,tr("*.raw"));
    if(savefilepath==NULL)return;
    outputfilename=savefilepath.toLatin1();

            FILE *fp;
            fp=fopen(outputfilename,"wb");
            if(!fp) return;


                for (int column=0;column<Ydim;column++)
                {
                    for (int row=0; row<Xdim;row++)
                    {

                        value=vol[row][column];//testing
                        value1=(unsigned char)value;
                        fwrite(&value1,sizeof(unsigned char),1,fp);
                    }
                }


            fclose(fp);
}

void MainWindow::on_actionExit_triggered()
{
    close();
}

void  MainWindow::draw_fullimage(unsigned short **vol)
{
    if(start==0)return;
    QImage imagez(Xdim,Ydim,QImage::Format_RGB32);
    int pixelValue;

    for(int j=0;j<Ydim;j++)
    {
        for(int i=0;i<Xdim;i++)
        {
            pixelValue=vol[i][j];
                imagez.setPixel(QPoint(i,j), qRgb(pixelValue,pixelValue,pixelValue));
        }
    }

    if(ui->actionShow_Gridlines->isChecked()==true)//Gridlines
    {

        for(int i=0;i<Ydim;i++)
        {
            imagez.setPixel(curX,i,qRgb(0, 0, 255) );
        }
        for(int i=0;i<Xdim;i++)
        {
            imagez.setPixel(i,curY,qRgb(255, 0, 0));
        }
    }
  //  ui->label_12->setNum(vol[curX][curY][curZ]);

    ui->sliceLabel->setMinimumHeight(zoomscale*(Ydim-1));
    ui->sliceLabel->setMinimumWidth(zoomscale*(Xdim-1));
    ui->sliceLabel->setPixmap(QPixmap::fromImage(imagez).scaled(imagez.width()*zoomscale,imagez.height()*zoomscale));
}

void MainWindow::mouseDoubleClickEvent(QMouseEvent *e)
{

}

void MainWindow::on_EDT_clicked()
{
    int i,j,flag1=0,p,q,r,iter=0,temp,maxdt=0;

        for(j=0;j<Ydim;j++)
        {
            for(i=0;i<Xdim;i++)
            {
                if(vol1[i][j])EDT[i][j]=60000;
                else EDT[i][j]=0;
            }
        }


    qDebug()<<"Before entering distane transform loop";

    do
    {
        flag1=0;

        for(j=0;j<Ydim;j++)//Forward Pass
        {
            for(i=0;i<Xdim;i++)
            {

                if(vol1[i][j])
                {
                    for(int n=0;n<13;n++)
                    {
                        p=i+npp[n][0];
                        q=j+npp[n][1];

                        if(p==i&&q==j)continue;
                        if(p>=0&&p<Xdim&&q>=0&&q<Ydim)
                        {
                            temp=EDT[p][q]+neighbor[n];
                            if(temp<EDT[i][j])
                            {
                                EDT[i][j]=temp;
                                flag1++;
                            }
                        }
                    }
                }
            }
        }



       // qDebug()<<"Before entering backward pass...........";

            for(j=Ydim-1;j>=0;j--)//Backward Pass
            {
                for(i=Xdim-1;i>=0;i--)
                {
                    if(vol1[i][j])
                    {
                        for(int n=14;n<27;n++)
                        {
                            p=i+npp[n][0];
                            q=j+npp[n][1];

                            if(p==i&&q==j)continue;
                            if(p>=0&&p<Xdim&&q>=0&&q<Ydim)
                            {
                                temp=EDT[p][q]+neighbor[n];
                                if(temp<EDT[i][j])
                                {
                                 EDT[i][j]=temp;
                                 flag1++;
                                }
                            }
                        }
                 }
              }
          }

        iter++;
    }while(flag1);

  for(j=0;j<Ydim;j++)
        {
            for(i=0;i<Xdim;i++)
            {
                if(EDT[i][j]>maxdt)
                {
                    maxdt=EDT[i][j];
                }
            }
        }

    md=maxdt;

        for(j=0;j<Ydim;j++)
        {
            for(i=0;i<Xdim;i++)
            {
               NDT[i][j]=(unsigned short)round((EDT[i][j]*255)/(double)maxdt);
            }
        }


    vol=NDT;
    draw_fullimage(vol);
    qDebug()<<"Maxdt positive DT="<<md;
}

void MainWindow::on_actionColorize_triggered()
{
    if(ui->actionColorize->isChecked())
    colorcode(colorMatrix,0,curZ);
    else draw_fullimage(vol);
}

void MainWindow::colorcode(unsigned short **array,int cth,int Z)
{
    int red=0,green=0,blue=0,i,j,k,hu,saturation=1;
    QImage imagez(Xdim,Ydim,QImage::Format_RGB32);
    double del=(360-cth)/4;

        for(j=0;j<Ydim;j++)
            {
                for(i=0;i<Xdim;i++)
                {
                    red=0;green=0;blue=0;
                    if(array[i][j])
                    {
                        hu=array[i][j];
                        if(hu<=cth){

                                blue=(hu/(double)cth)*255;
//                                if(ui->blackBG->isChecked())
//                                {
//                                    blue=0;
//                                }
                                //qDebug()<<"Value of Hu="<<hu<<","<<"Value of Blue="<<blue;
                                blue=0;
                        }

                        if(hu>cth&&hu<=(cth+del)){

                                blue=255*saturation;
                                green=((hu-cth)/del)*255*saturation;//+255*(1-saturation));
                                red=0;
                        }
                        if(hu>(cth+del)&&hu<=(cth+2*del)){
                            blue=(((cth+2*del)-hu)/del)*255*saturation;//255*(1-saturation);
                            green=255*saturation;
                            red=0;
                        }
                        if(hu>(cth+2*del)&&hu<=(cth+3*del)){
                            blue=0;
                            green=255*saturation;
                            red=((hu-(cth+2*del))/del)*255*saturation;//+255*(1-saturation);
                        }
                        if(hu>(cth+3*del)&&hu<=360){
                            blue=0;//255*(1-saturation);
                            green=((360.0-hu)/del)*255*saturation;//+255*(1-saturation);
                            red=255*(saturation);
                        }

                        imagez.setPixel(i,j,qRgb(red,green,blue));
                    }
                    //if(!red&&!blue&&!green&&a[i][j])image1.setPixel(i,j,qRgb(255,255,255));
                    if(!vol1[i][j])imagez.setPixel(i,j,qRgb(0,0,0));
                }
            }


    ui->sliceLabel->setMinimumHeight(zoomscale*(Ydim-1));
    ui->sliceLabel->setMinimumWidth(zoomscale*(Xdim-1));
    ui->sliceLabel->setPixmap(QPixmap::fromImage(imagez).scaled(imagez.width()*zoomscale,imagez.height()*zoomscale));
}

void MainWindow::colorcode2D(unsigned short **array, int cth, int Xdim, int Ydim)
{
    int red=0,green=0,blue=0,i,j,hu,saturation=1;
    QImage imagez(Xdim,Ydim,QImage::Format_RGB32);
    double del=(360-cth)/4;

        for(j=0;j<Ydim;j++)
            {
                for(i=0;i<Xdim;i++)
                {
                    red=0;green=0;blue=0;
                    if(array[i][j])
                    {
                        hu=array[i][j];
                        if(hu<=cth){

                                blue=(hu/(double)cth)*255;
//                                if(ui->blackBG->isChecked())
//                                {
//                                    blue=0;
//                                }
                                //qDebug()<<"Value of Hu="<<hu<<","<<"Value of Blue="<<blue;
                                blue=0;
                        }

                        if(hu>cth&&hu<=(cth+del)){

                                blue=255*saturation;
                                green=((hu-cth)/del)*255*saturation;//+255*(1-saturation));
                                red=0;
                        }
                        if(hu>(cth+del)&&hu<=(cth+2*del)){
                            blue=(((cth+2*del)-hu)/del)*255*saturation;//255*(1-saturation);
                            green=255*saturation;
                            red=0;
                        }
                        if(hu>(cth+2*del)&&hu<=(cth+3*del)){
                            blue=0;
                            green=255*saturation;
                            red=((hu-(cth+2*del))/del)*255*saturation;//+255*(1-saturation);
                        }
                        if(hu>(cth+3*del)&&hu<=360){
                            blue=0;//255*(1-saturation);
                            green=((360.0-hu)/del)*255*saturation;//+255*(1-saturation);
                            red=255*(saturation);
                        }
                    }
                    imagez.setPixel(i,j,qRgb(red,green,blue));
                    //if(!red&&!blue&&!green&&a[i][j])image1.setPixel(i,j,qRgb(255,255,255));
                    //if(!array[][])imagez.setPixel(i,j,qRgb(0,0,0));
                }
            }

    ui->sliceLabel->setMinimumHeight(zoomscale*(Ydim-1));
    ui->sliceLabel->setMinimumWidth(zoomscale*(Xdim-1));
    ui->sliceLabel->setPixmap(QPixmap::fromImage(imagez).scaled(imagez.width()*zoomscale,imagez.height()*zoomscale));
}

void MainWindow::on_surface_clicked()
{
   int i,j,k,p,q,r,n,bc=0;


           for(j=0;j<Ydim;j++)
           {
               for(i=0;i<Xdim;i++)
               {
                   if(vol1[i][j])
                   {
                       for(n=0;n<27;n++)
                       {
                           p=i+npp[n][0];
                           q=j+npp[n][1];
                           r=k+npp[n][2];
                           if(vol1[p][q]==0)
                           {
                              boundary[i][j]=1;
                              bc++;
                              //boundary[p][q][r]=1;
                              break;
                           }
                       }

                   }
               }
           }

   qDebug()<<"Total number of boundary points"<<bc;
   vol=boundary;
}

void MainWindow::on_recons_clicked()
{
    readCore();
    grow();
}

void MainWindow::readCore()
{
    FILE *fp;
    fp=fopen("CCL_Core_Half_OUTPigL_813x903x1053_ISOAV_EDT_th190.img","rb");
    int i,j,k;
    unsigned char val1;
    unsigned short val;

        for(j=0;j<Ydim;j++)
        {
            for(i=0;i<Xdim;i++)
            {
                fread(&val1,sizeof(unsigned char),1,fp);
                core[i][j]=(unsigned short)val1;
                if(core[i][j]==255)core[i][j]=2;
                coreA[i][j]=0;
                coreV[i][j]=0;
                common[i][j]=0;
            }
        }


    fclose(fp);


        for(j=0;j<Ydim;j++)
        {
            for(i=0;i<Xdim;i++)
            {
                if(core[i][j]==1)
                {
                    coreA[i][j]=1;
                    //qDebug()<<"Artery assigned"<<coreA[i][j][k];
                }
                if(core[i][j]==2)
                {
                    coreV[i][j]=2;
                    //qDebug()<<"vein assigned"<<coreV[i][j][k];
                }
            }
        }


}

void MainWindow::grow()
{
   int j,k,i=0,x,y,z,p,q,r;

   while(1)
   {
      k=md-i;
      if(k<=0)break;
      else
      {

             for(y=0;y<Ydim;y++)
             {
                 for(x=0;x<Xdim;x++)
                 {
                   if(core[x][y]==1)
                   {
                      //int f=0;


                              for(q=y-1;q<=y+1;q++)
                              {
                                  for(p=x-1;p<=x+1;p++)
                                  {
                                      if(p<0||q<0||r<0||p>=Xdim||q>=Ydim)continue;
                                      if(EDT[p][q]==k&&!common[p][q])
                                      {
                                          core[p][q]=1;
                                          coreA[p][q]=1;
                                      }
                                  }

                              }

                   }

                   if(core[x][y]==2)
                   {
                      //int f=0;


                              for(q=y-1;q<=y+1;q++)
                              {
                                  for(p=x-1;p<=x+1;p++)
                                  {
                                      if(p<0||q<0||p>=Xdim||q>=Ydim)continue;
                                      if(EDT[p][q]==k&&!common[p][q])
                                      {
                                          core[p][q]=2;
                                          coreV[p][q]=2;
                                      }
                                  }
                              }

                   }

                 }
             }


             for(int jj=0;jj<Ydim;jj++)
             {
                 for(int ii=0;ii<Xdim;ii++)
                 {
                     if(coreA[ii][jj]==1&&coreV[ii][jj]==2)
                     {
                         common[ii][jj]=1;
                         coreA[ii][jj]=0;
                         coreV[ii][jj]=0;
                         core[ii][jj]=0;
                     }
                     else common[ii][jj]=0;
                 }
             }

      }
      i++;
   }

       for(j=0;j<Ydim;j++)
       {
           for(i=0;i<Xdim;i++)
           {
               if(common[i][j]==1)core[i][j]=3;
           }
       }


   draw_fullimage(core);
   vol=core;
}
